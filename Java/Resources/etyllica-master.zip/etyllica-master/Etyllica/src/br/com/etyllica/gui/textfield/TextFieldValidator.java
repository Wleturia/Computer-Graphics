package br.com.etyllica.gui.textfield;

/**
 * 
 * @author yuripourre
 * @license LGPLv3
 *
 */

public interface TextFieldValidator {

	public String validate(String text);
	
}
