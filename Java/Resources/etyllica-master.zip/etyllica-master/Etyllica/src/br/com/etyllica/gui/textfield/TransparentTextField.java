package br.com.etyllica.gui.textfield;

import br.com.etyllica.gui.TextField;

/**
 * 
 * @author yuripourre
 * @license LGPLv3
 *
 */

public class TransparentTextField extends TextField{

	public TransparentTextField(int x, int y, int w, int h) {
		super(x, y, w, h);
	}
		
	
}
