package br.com.etyllica.gui.mouse.arrow;

import br.com.etyllica.core.Drawable;


/**
 * 
 * @author yuripourre
 * @license LGPLv3
 *
 */

public interface MouseArrow extends Drawable{
	
	public void move(int mx, int my);
	
}
