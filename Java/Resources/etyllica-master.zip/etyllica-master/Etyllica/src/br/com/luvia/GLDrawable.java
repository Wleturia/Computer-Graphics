package br.com.luvia;

import org.jgl.GLAUX;

/**
 * 
 * @author yuripourre
 * @license LGPLv3
 *
 */

public interface GLDrawable {

	public void draw(GLAUX gl);
	
}
