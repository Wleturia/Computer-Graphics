package br.com.etyllica.gui;


public class MultipleSelect extends Select{

	public MultipleSelect(int x, int y, int w, int h) {
		super(x, y, w, h);
	}
	
}