package br.com.etyllica.gui.label;

import br.com.etyllica.gui.Label;

public abstract class Icon extends Label{

	public Icon(int x, int y){
		super(x,y);
	}

}
