package br.com.etyllica.core;

public interface Engine {

	public void draw();
	
	public void update();
	
}
