package br.com.etyllica.core.application.load;


/**
 * 
 * @author yuripourre
 * @license LGPLv3
 *
 */

public interface LoadApplication{

	public void setText(String phrase, float load);
	
	public void load();

}