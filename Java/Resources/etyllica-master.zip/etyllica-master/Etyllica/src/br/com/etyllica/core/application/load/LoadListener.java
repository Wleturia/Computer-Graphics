package br.com.etyllica.core.application.load;

public interface LoadListener {

	public void loaded();
	
}
