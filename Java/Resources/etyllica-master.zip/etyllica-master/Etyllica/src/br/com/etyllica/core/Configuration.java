package br.com.etyllica.core;

import br.com.etyllica.core.theme.Theme;
import br.com.etyllica.gui.mouse.theme.ArrowTheme;
import br.com.etyllica.i18n.Language;
import br.com.etyllica.theme.EtyllicTheme;

/**
 * 
 * @author yuripourre
 * @license LGPLv3
 *
 */

public class Configuration {

	private static Configuration instance = null;
	
		
	private Theme theme = new EtyllicTheme();
	private ArrowTheme arrowTheme = new ArrowTheme();
	
	//private Language lang = Language.JAPANESE;
	//private Language lang = Language.ENGLISH_USA;
	private Language language = Language.PORTUGUESE_BRAZIL;
		
	
	private boolean timerClick = false;
	private boolean numpadMouse = false;
	
	private boolean languageChanged = false;
	private boolean themeChanged = false;
	
	private Configuration(){
		super();
	}

	public static Configuration getInstance() {
		if(instance==null){
			instance = new Configuration();
		}

		return instance;
	}
	
	public Theme getTheme() {
		return theme;
	}

	public void setTheme(Theme theme) {
		this.theme = theme;
	}
	
	public ArrowTheme getArrowTheme() {
		return arrowTheme;
	}

	/**
	 * 
	 * @param arrowTheme
	 */
	public void setArrowTheme(ArrowTheme arrowTheme) {
		this.arrowTheme = arrowTheme;
	}

	public Language getLanguage() {
		return language;
	}

	/**
	 * 
	 * @param language
	 */
	public void setLanguage(Language language) {
		this.language = language;
		
		if(language==Language.JAPANESE){
			theme.setFontName(Theme.FONT_JAPANESE);
		}else{
			theme.setFontName(Theme.FONT_DEFAULT);
		}
		
		theme.reloadFonts();
		
		setLanguageChanged(true);
		
		//TODO Each component is responsible for it
		//addGUIEvent(GUIEvent.LANGUAGE_CHANGED);
	}

	public boolean isTimerClick() {
		return timerClick;
	}

	/**
	 * 
	 * @param timerClick
	 */
	public void setTimerClick(boolean timerClick) {
		this.timerClick = timerClick;
	}

	public boolean isNumpadMouse() {
		return numpadMouse;
	}

	/**
	 * 
	 * @param numpadMouse
	 */
	public void setNumpadMouse(boolean numpadMouse) {
		this.numpadMouse = numpadMouse;
	}

	public boolean isLanguageChanged() {
		return languageChanged;
	}

	/**
	 * 
	 * @param languageChanged
	 */
	public void setLanguageChanged(boolean languageChanged) {
		this.languageChanged = languageChanged;
	}
	
	public boolean isThemeChanged() {
		return themeChanged;
	}
	
	/**
	 * 
	 * @param themeChanged
	 */
	public void setThemeChanged(boolean themeChanged) {
		this.themeChanged = themeChanged;
	}
	

}
