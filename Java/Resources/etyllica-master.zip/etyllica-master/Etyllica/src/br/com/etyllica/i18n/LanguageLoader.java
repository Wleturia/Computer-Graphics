package br.com.etyllica.i18n;

import br.com.etyllica.core.loader.Loader;

/**
 * 
 * @author yuripourre
 * @license GPLv3
 *
 */

public class LanguageLoader extends Loader{

	private LanguageLoader(){
		super();
		
		folder = "lang/";
	}
	
}
