package org.jgl.has;

import org.jgl.GL;
import org.jgl.GLU;


public class HasGLU {
	
	protected GL gl;
	protected GLU glu;
	
	public HasGLU (GLU glu) {
		this.gl = glu;
		this.glu = glu;
	}
}
