package org.jgl.has;

import org.jgl.GL;


public class HasGL {
	
	protected GL gl;
	
	public HasGL (GL gl) {
		this.gl = gl;
	}
}
