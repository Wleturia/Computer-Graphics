/*
 * Copyright (c) 1993-1997, Silicon Graphics, Inc.
 * ALL RIGHTS RESERVED 
 * Permission to use, copy, modify, and distribute this software for 
 * any purpose and without fee is hereby granted, provided that the above
 * copyright notice appear in all copies and that both the copyright notice
 * and this permission notice appear in supporting documentation, and that 
 * the name of Silicon Graphics, Inc. not be used in advertising
 * or publicity pertaining to distribution of the software without specific,
 * written prior permission. 
 *
 * THE MATERIAL EMBODIED ON THIS SOFTWARE IS PROVIDED TO YOU "AS-IS"
 * AND WITHOUT WARRANTY OF ANY KIND, EXPRESS, IMPLIED OR OTHERWISE,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY OR
 * FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL SILICON
 * GRAPHICS, INC.  BE LIABLE TO YOU OR ANYONE ELSE FOR ANY DIRECT,
 * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
 * KIND, OR ANY DAMAGES WHATSOEVER, INCLUDING WITHOUT LIMITATION,
 * LOSS OF PROFIT, LOSS OF USE, SAVINGS OR REVENUE, OR THE CLAIMS OF
 * THIRD PARTIES, WHETHER OR NOT SILICON GRAPHICS, INC.  HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH LOSS, HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE
 * POSSESSION, USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 * US Government Users Restricted Rights 
 * Use, duplication, or disclosure by the Government is subject to
 * restrictions set forth in FAR 52.227.19(c)(2) or subparagraph
 * (c)(1)(ii) of the Rights in Technical Data and Computer Software
 * clause at DFARS 252.227-7013 and/or in similar or successor
 * clauses in the FAR or the DOD or NASA FAR Supplement.
 * Unpublished-- rights reserved under the copyright laws of the
 * United States.  Contractor/manufacturer is Silicon Graphics,
 * Inc., 2011 N.  Shoreline Blvd., Mountain View, CA 94039-7311.
 *
 * OpenGL(R) is a registered trademark of Silicon Graphics, Inc.
 */

/*
 *  tesswind.c
 *  This program demonstrates the winding rule polygon 
 *  tessellation property.  Four tessellated objects are drawn, 
 *  each with very different contours.  When the w key is pressed, 
 *  the objects are drawn with a different winding rule.
 */
/*
 * Tesswind.java
 * JSparrow version of "tesswind.c" on Red Book
 *     PFU Limited.  1999
 */
import jsparrow.gl.*;
import java.awt.*;
import java.awt.event.*;

public class Tesswind extends OGLCanvas {
    double currentWinding = GLU_TESS_WINDING_ODD;
    int currentShape = 0;
    GLUtesselator tobj;
    int list;
    
/*  Make four display lists, 
 *  each with a different tessellated object. 
 */
    void makeNewLists () {
        int i;
        double rects[][] = 
            {{50.0, 50.0, 0.0}, {300.0, 50.0, 0.0}, 
             {300.0, 300.0, 0.0}, {50.0, 300.0, 0.0},
             {100.0, 100.0, 0.0}, {250.0, 100.0, 0.0}, 
             {250.0, 250.0, 0.0}, {100.0, 250.0, 0.0},
             {150.0, 150.0, 0.0}, {200.0, 150.0, 0.0}, 
             {200.0, 200.0, 0.0}, {150.0, 200.0, 0.0}};
        double spiral[][] = 
            {{400.0, 250.0, 0.0}, {400.0, 50.0, 0.0}, 
             {50.0, 50.0, 0.0}, {50.0, 400.0, 0.0}, 
             {350.0, 400.0, 0.0}, {350.0, 100.0, 0.0}, 
             {100.0, 100.0, 0.0}, {100.0, 350.0, 0.0}, 
             {300.0, 350.0, 0.0}, {300.0, 150.0, 0.0}, 
             {150.0, 150.0, 0.0}, {150.0, 300.0, 0.0}, 
             {250.0, 300.0, 0.0}, {250.0, 200.0, 0.0}, 
             {200.0, 200.0, 0.0}, {200.0, 250.0, 0.0}};
        double quad1[][] = 
            {{50.0, 150.0, 0.0}, {350.0, 150.0, 0.0}, 
             {350.0, 200.0, 0.0}, {50.0, 200.0, 0.0}};
        double quad2[][] =
            {{100.0, 100.0, 0.0}, {300.0, 100.0, 0.0}, 
             {300.0, 350.0, 0.0}, {100.0, 350.0, 0.0}};
        double tri[][] =
            {{200.0, 50.0, 0.0}, {250.0, 300.0, 0.0},
             {150.0, 300.0, 0.0}};
 
        gluTessProperty(tobj, GLU_TESS_WINDING_RULE, 
                        currentWinding);

        glNewList(list, GL_COMPILE);
            gluTessBeginPolygon(tobj, (Object)null);
            gluTessBeginContour(tobj);
                for (i = 0; i < 4; i++)
                    gluTessVertex(tobj, rects[i], rects[i]);
                gluTessEndContour(tobj);
                gluTessBeginContour(tobj);
                for (i = 4; i < 8; i++)
                    gluTessVertex(tobj, rects[i], rects[i]);
                gluTessEndContour(tobj);
                gluTessBeginContour(tobj);
                for (i = 8; i < 12; i++)
                    gluTessVertex(tobj, rects[i], rects[i]);
                gluTessEndContour(tobj);
            gluTessEndPolygon(tobj);
        glEndList();

        glNewList(list+1, GL_COMPILE);
            gluTessBeginPolygon(tobj, (Object)null);
                gluTessBeginContour(tobj);
                for (i = 0; i < 4; i++)
                gluTessVertex(tobj, rects[i], rects[i]);
                gluTessEndContour(tobj);
                gluTessBeginContour(tobj);
                for (i = 7; i >= 4; i--)
                gluTessVertex(tobj, rects[i], rects[i]);
                gluTessEndContour(tobj);
                gluTessBeginContour(tobj);
                for (i = 11; i >= 8; i--)
                gluTessVertex(tobj, rects[i], rects[i]);
                gluTessEndContour(tobj);
            gluTessEndPolygon(tobj);
        glEndList();

        glNewList(list+2, GL_COMPILE);
            gluTessBeginPolygon(tobj, (Object)null);
                gluTessBeginContour(tobj);
                for (i = 0; i < 16; i++)
                    gluTessVertex(tobj, spiral[i], spiral[i]);
                gluTessEndContour(tobj);
            gluTessEndPolygon(tobj);
        glEndList();

        glNewList(list+3, GL_COMPILE);
            gluTessBeginPolygon(tobj, (Object)null);
                gluTessBeginContour(tobj);
                for (i = 0; i < 4; i++)
                    gluTessVertex(tobj, quad1[i], quad1[i]);
                gluTessEndContour(tobj);
                gluTessBeginContour(tobj);
                for (i = 0; i < 4; i++)
                    gluTessVertex(tobj, quad2[i], quad2[i]);
                gluTessEndContour(tobj);
                gluTessBeginContour(tobj);
                for (i = 0; i < 3; i++)
                    gluTessVertex(tobj, tri[i], tri[i]);
                gluTessEndContour(tobj);
            gluTessEndPolygon(tobj);
        glEndList();
    }

    void display () {
        glClear(GL_COLOR_BUFFER_BIT);
        glColor3f(1.0f, 1.0f, 1.0f);
        glPushMatrix(); 
        glCallList(list);
        glTranslatef(0.0f, 500.0f, 0.0f);
        glCallList(list+1);
        glTranslatef(500.0f, -500.0f, 0.0f);
        glCallList(list+2);
        glTranslatef(0.0f, 500.0f, 0.0f);
        glCallList(list+3);
        glPopMatrix(); 
        glFlush();
    }

    void /*CALLBACK*/ beginCallback(int which) {
        glBegin(which);
    }

    void /*CALLBACK*/ errorCallback(int errorCode) {
        String estring;

        estring = gluErrorString(errorCode);
        System.out.println("Tessellation Error: " + estring);
        System.exit(0);
    }

    void /*CALLBACK*/ endCallback() {
        glEnd();
    }

/*  combineCallback is used to create a new vertex when edges
 *  intersect.  coordinate location is trivial to calculate,
 *  but weight[4] may be used to average color, normal, or texture 
 *  coordinate data.
 */
    void /*CALLBACK*/ combineCallback(double coords[], double data[][],
                     float weight[], Object[] dataOut ) {
        double vertex[];
        vertex = new double[3];

        vertex[0] = coords[0];
        vertex[1] = coords[1];
        vertex[2] = coords[2];
        dataOut[0] = vertex;
    }

    public void init() {
        glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        glShadeModel(GL_FLAT);    

        tobj = gluNewTess();
        gluTessCallback(tobj, GLU_TESS_VERTEX, 
                        "glVertex3dv", this);
        gluTessCallback(tobj, GLU_TESS_BEGIN, 
                        "beginCallback", this);
        gluTessCallback(tobj, GLU_TESS_END, 
                        "endCallback", this);
        gluTessCallback(tobj, GLU_TESS_ERROR, 
                        "errorCallback", this);
        gluTessCallback(tobj, GLU_TESS_COMBINE, 
                        "combineCallback", this);

        list = glGenLists(4);
        makeNewLists();
    }

    void reshape(int w, int h) {
        glViewport(0, 0, w, h);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        if (w <= h)
            gluOrtho2D(0.0, 1000.0, 0.0, 1000.0 * (double)h/(double)w);
        else
            gluOrtho2D(0.0, 1000.0 * (double)w/(double)h, 0.0, 1000.0);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
    }

    void keyboard(char key, int x, int y) {
        switch (key) {
            case 'w':
            case 'W':
                if (currentWinding == GLU_TESS_WINDING_ODD)
                    currentWinding = GLU_TESS_WINDING_NONZERO;
                else if (currentWinding == GLU_TESS_WINDING_NONZERO)
                    currentWinding = GLU_TESS_WINDING_POSITIVE;
                else if (currentWinding == GLU_TESS_WINDING_POSITIVE)
                    currentWinding = GLU_TESS_WINDING_NEGATIVE;
                else if (currentWinding == GLU_TESS_WINDING_NEGATIVE)
                    currentWinding = GLU_TESS_WINDING_ABS_GEQ_TWO;
                else if (currentWinding == GLU_TESS_WINDING_ABS_GEQ_TWO)
                    currentWinding = GLU_TESS_WINDING_ODD;
                makeNewLists();
                glutPostRedisplay();
                break;
            case 27:
                System.exit(0);
                break;
            default:
                break;
        }
    }

    int main() {
        glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
        glutInitWindowSize(500, 500);
        OGLContext context = jsCreateContextAuto();
        jsInitFunc("init", this, context);
        glutDisplayFunc("display", this, context);
        glutReshapeFunc("reshape", this, context);
        glutKeyboardFunc("keyboard", this, context);
        return 0;  
    }

    public static void main(String argv[]) {
        Tesswind canvas = new Tesswind();
        canvas.main();
        Frame frame = new Frame("tesswind");
        frame.add(canvas);
        frame.pack();
        frame.show();
    }
}
