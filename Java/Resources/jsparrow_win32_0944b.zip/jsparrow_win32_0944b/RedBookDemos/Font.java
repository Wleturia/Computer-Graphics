/*
 * Copyright (c) 1993-1997, Silicon Graphics, Inc.
 * ALL RIGHTS RESERVED 
 * Permission to use, copy, modify, and distribute this software for 
 * any purpose and without fee is hereby granted, provided that the above
 * copyright notice appear in all copies and that both the copyright notice
 * and this permission notice appear in supporting documentation, and that 
 * the name of Silicon Graphics, Inc. not be used in advertising
 * or publicity pertaining to distribution of the software without specific,
 * written prior permission. 
 *
 * THE MATERIAL EMBODIED ON THIS SOFTWARE IS PROVIDED TO YOU "AS-IS"
 * AND WITHOUT WARRANTY OF ANY KIND, EXPRESS, IMPLIED OR OTHERWISE,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY OR
 * FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL SILICON
 * GRAPHICS, INC.  BE LIABLE TO YOU OR ANYONE ELSE FOR ANY DIRECT,
 * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
 * KIND, OR ANY DAMAGES WHATSOEVER, INCLUDING WITHOUT LIMITATION,
 * LOSS OF PROFIT, LOSS OF USE, SAVINGS OR REVENUE, OR THE CLAIMS OF
 * THIRD PARTIES, WHETHER OR NOT SILICON GRAPHICS, INC.  HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH LOSS, HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE
 * POSSESSION, USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 * US Government Users Restricted Rights 
 * Use, duplication, or disclosure by the Government is subject to
 * restrictions set forth in FAR 52.227.19(c)(2) or subparagraph
 * (c)(1)(ii) of the Rights in Technical Data and Computer Software
 * clause at DFARS 252.227-7013 and/or in similar or successor
 * clauses in the FAR or the DOD or NASA FAR Supplement.
 * Unpublished-- rights reserved under the copyright laws of the
 * United States.  Contractor/manufacturer is Silicon Graphics,
 * Inc., 2011 N.  Shoreline Blvd., Mountain View, CA 94039-7311.
 *
 * OpenGL(R) is a registered trademark of Silicon Graphics, Inc.
 */

/*
 *  font.c
 *
 *  Draws some text in a bitmapped font.  Uses glBitmap() 
 *  and other pixel routines.  Also demonstrates use of 
 *  display lists.
 */

/*
 * Font.java
 * JSparrow version of "font.c" on Red Book
 *     PFU Limited.  1998
 */
import jsparrow.gl.*;
import java.awt.*;
import java.awt.event.*;

public class Font extends OGLCanvas {

    byte space[] = 
    {(byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00};
    
    byte letters[][] = {
    {(byte)0x00, (byte)0x00, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xff, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0x66, (byte)0x3c, (byte)0x18}, 
    {(byte)0x00, (byte)0x00, (byte)0xfe, (byte)0xc7, (byte)0xc3, (byte)0xc3, (byte)0xc7, (byte)0xfe, (byte)0xc7, (byte)0xc3, (byte)0xc3, (byte)0xc7, (byte)0xfe}, 
    {(byte)0x00, (byte)0x00, (byte)0x7e, (byte)0xe7, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xe7, (byte)0x7e}, 
    {(byte)0x00, (byte)0x00, (byte)0xfc, (byte)0xce, (byte)0xc7, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc7, (byte)0xce, (byte)0xfc}, 
    {(byte)0x00, (byte)0x00, (byte)0xff, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xfc, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xff}, 
    {(byte)0x00, (byte)0x00, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xfc, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xff}, 
    {(byte)0x00, (byte)0x00, (byte)0x7e, (byte)0xe7, (byte)0xc3, (byte)0xc3, (byte)0xcf, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xe7, (byte)0x7e}, 
    {(byte)0x00, (byte)0x00, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xff, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3}, 
    {(byte)0x00, (byte)0x00, (byte)0x7e, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x7e}, 
    {(byte)0x00, (byte)0x00, (byte)0x7c, (byte)0xee, (byte)0xc6, (byte)0x06, (byte)0x06, (byte)0x06, (byte)0x06, (byte)0x06, (byte)0x06, (byte)0x06, (byte)0x06}, 
    {(byte)0x00, (byte)0x00, (byte)0xc3, (byte)0xc6, (byte)0xcc, (byte)0xd8, (byte)0xf0, (byte)0xe0, (byte)0xf0, (byte)0xd8, (byte)0xcc, (byte)0xc6, (byte)0xc3}, 
    {(byte)0x00, (byte)0x00, (byte)0xff, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0}, 
    {(byte)0x00, (byte)0x00, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xdb, (byte)0xff, (byte)0xff, (byte)0xe7, (byte)0xc3}, 
    {(byte)0x00, (byte)0x00, (byte)0xc7, (byte)0xc7, (byte)0xcf, (byte)0xcf, (byte)0xdf, (byte)0xdb, (byte)0xfb, (byte)0xf3, (byte)0xf3, (byte)0xe3, (byte)0xe3},
    {(byte)0x00, (byte)0x00, (byte)0x7e, (byte)0xe7, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xe7, (byte)0x7e}, 
    {(byte)0x00, (byte)0x00, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xc0, (byte)0xfe, (byte)0xc7, (byte)0xc3, (byte)0xc3, (byte)0xc7, (byte)0xfe}, 
    {(byte)0x00, (byte)0x00, (byte)0x3f, (byte)0x6e, (byte)0xdf, (byte)0xdb, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0x66, (byte)0x3c}, 
    {(byte)0x00, (byte)0x00, (byte)0xc3, (byte)0xc6, (byte)0xcc, (byte)0xd8, (byte)0xf0, (byte)0xfe, (byte)0xc7, (byte)0xc3, (byte)0xc3, (byte)0xc7, (byte)0xfe}, 
    {(byte)0x00, (byte)0x00, (byte)0x7e, (byte)0xe7, (byte)0x03, (byte)0x03, (byte)0x07, (byte)0x7e, (byte)0xe0, (byte)0xc0, (byte)0xc0, (byte)0xe7, (byte)0x7e}, 
    {(byte)0x00, (byte)0x00, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0xff}, 
    {(byte)0x00, (byte)0x00, (byte)0x7e, (byte)0xe7, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3}, 
    {(byte)0x00, (byte)0x00, (byte)0x18, (byte)0x3c, (byte)0x3c, (byte)0x66, (byte)0x66, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3}, 
    {(byte)0x00, (byte)0x00, (byte)0xc3, (byte)0xe7, (byte)0xff, (byte)0xff, (byte)0xdb, (byte)0xdb, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3, (byte)0xc3}, 
    {(byte)0x00, (byte)0x00, (byte)0xc3, (byte)0x66, (byte)0x66, (byte)0x3c, (byte)0x3c, (byte)0x18, (byte)0x3c, (byte)0x3c, (byte)0x66, (byte)0x66, (byte)0xc3}, 
    {(byte)0x00, (byte)0x00, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x18, (byte)0x3c, (byte)0x3c, (byte)0x66, (byte)0x66, (byte)0xc3}, 
    {(byte)0x00, (byte)0x00, (byte)0xff, (byte)0xc0, (byte)0xc0, (byte)0x60, (byte)0x30, (byte)0x7e, (byte)0x0c, (byte)0x06, (byte)0x03, (byte)0x03, (byte)0xff}
    };
    
    int fontOffset;
    
    void makeRasterFont(){
        int i, j;
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        
        fontOffset = glGenLists (128);
        for (i = 0,j = 'A'; i < 26; i++,j++) {
            glNewList(fontOffset + j, GL_COMPILE);
            glBitmap(8, 13, 0.0f, 2.0f, 10.0f, 0.0f, letters[i]);
            glEndList();
        }
        glNewList(fontOffset + ' ', GL_COMPILE);
        glBitmap(8, 13, 0.0f, 2.0f, 10.0f, 0.0f, space);
        glEndList();
    }
    
    public void init() {
        glShadeModel (GL_FLAT);
        makeRasterFont();
    }

    void printString(String s) {
        glPushAttrib (GL_LIST_BIT);
        glListBase(fontOffset);
        glCallLists(s.length(), GL_UNSIGNED_BYTE, s.getBytes());
        glPopAttrib ();
    }
    
/* Everything above this line could be in a library 
 * that defines a font.  To make it work, you've got 
 * to call makeRasterFont() before you start making 
 * calls to printString().
 */
    public void display() {
        float white[] = { 1.0f, 1.0f, 1.0f };
        
        glClear(GL_COLOR_BUFFER_BIT);
        glColor3fv(white);
        
        glRasterPos2i(20, 60);
        printString("THE QUICK BROWN FOX JUMPS");
        glRasterPos2i(20, 40);
        printString("OVER A LAZY DOG");
        glFlush ();
    }

    public void reshape(int w, int h) {
        glViewport(0, 0, w, h);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho (0.0, w, 0.0, h, -1.0, 1.0);
        glMatrixMode(GL_MODELVIEW);
    }

    public void keyboard(char key, int x, int y) {
        switch (key) {
            case 27:
                System.exit(0);
        }
    }

/*  Main Loop
 *  Open window with initial window size, title bar, 
 *  RGBA display mode, and handle input events.
 */
    int main() {
        glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
        glutInitWindowSize(300, 100);
        OGLContext context = jsCreateContextAuto();
        jsInitFunc("init", this, context);
        glutReshapeFunc("reshape", this, context);
        glutKeyboardFunc("keyboard", this, context);
        glutDisplayFunc("display", this,context);
        return 0;
    }

    public static void main(String argv[]) {
        Font canvas = new Font();
        canvas.main();
        Frame frame = new Frame("font");
        frame.add(canvas);
        frame.pack();
        frame.show();
    }
}
