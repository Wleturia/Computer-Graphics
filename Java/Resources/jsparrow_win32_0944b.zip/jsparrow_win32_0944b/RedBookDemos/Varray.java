/*
 * Copyright (c) 1993-1997, Silicon Graphics, Inc.
 * ALL RIGHTS RESERVED 
 * Permission to use, copy, modify, and distribute this software for 
 * any purpose and without fee is hereby granted, provided that the above
 * copyright notice appear in all copies and that both the copyright notice
 * and this permission notice appear in supporting documentation, and that 
 * the name of Silicon Graphics, Inc. not be used in advertising
 * or publicity pertaining to distribution of the software without specific,
 * written prior permission. 
 *
 * THE MATERIAL EMBODIED ON THIS SOFTWARE IS PROVIDED TO YOU "AS-IS"
 * AND WITHOUT WARRANTY OF ANY KIND, EXPRESS, IMPLIED OR OTHERWISE,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY OR
 * FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL SILICON
 * GRAPHICS, INC.  BE LIABLE TO YOU OR ANYONE ELSE FOR ANY DIRECT,
 * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
 * KIND, OR ANY DAMAGES WHATSOEVER, INCLUDING WITHOUT LIMITATION,
 * LOSS OF PROFIT, LOSS OF USE, SAVINGS OR REVENUE, OR THE CLAIMS OF
 * THIRD PARTIES, WHETHER OR NOT SILICON GRAPHICS, INC.  HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH LOSS, HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE
 * POSSESSION, USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 * US Government Users Restricted Rights 
 * Use, duplication, or disclosure by the Government is subject to
 * restrictions set forth in FAR 52.227.19(c)(2) or subparagraph
 * (c)(1)(ii) of the Rights in Technical Data and Computer Software
 * clause at DFARS 252.227-7013 and/or in similar or successor
 * clauses in the FAR or the DOD or NASA FAR Supplement.
 * Unpublished-- rights reserved under the copyright laws of the
 * United States.  Contractor/manufacturer is Silicon Graphics,
 * Inc., 2011 N.  Shoreline Blvd., Mountain View, CA 94039-7311.
 *
 * OpenGL(R) is a registered trademark of Silicon Graphics, Inc.
 */

/*
 *  varray.c
 *  This program demonstrates vertex arrays.
 */

/*
 * Varray.java
 * JSparrow version of "array.c" on Red Book
 *     PFU Limited.  1998
 */
import jsparrow.gl.*;
import java.awt.*;
import java.awt.event.*;

public class Varray extends OGLCanvas implements MouseListener {
    final int POINTER = 1;
    final int INTERLEAVED = 2;
    final int DRAWARRAY = 1;
    final int ARRAYELEMENT = 2;
    final int DRAWELEMENTS = 3;
    
    int setupMethod = POINTER;
    int derefMethod = DRAWARRAY;
    
    void setupPointers() {
        int vertices[] = {25, 25,
                          100, 325,
                          175, 25,
                          175, 325,
                          250, 25,
                          325, 325};
        float colors[] = {1.0f, 0.2f, 0.2f,
                          0.2f, 0.2f, 1.0f,
                          0.8f, 1.0f, 0.2f,
                          0.75f, 0.75f, 0.75f,
                          0.35f, 0.35f, 0.35f,
                          0.5f, 0.5f, 0.5f};
        
        glEnableClientState (GL_VERTEX_ARRAY);
        glEnableClientState (GL_COLOR_ARRAY);
        
        glVertexPointer (2, GL_INT, 0, vertices);
        glColorPointer (3, GL_FLOAT, 0, colors);
    }
    
    void setupInterleave() {
        float intertwined[] =
            {1.0f, 0.2f, 1.0f, 100.0f, 100.0f, 0.0f,
            1.0f, 0.2f, 0.2f, 0.0f, 200.0f, 0.0f,
            1.0f, 1.0f, 0.2f, 100.0f, 300.0f, 0.0f,
            0.2f, 1.0f, 0.2f, 200.0f, 300.0f, 0.0f,
            0.2f, 1.0f, 1.0f, 300.0f, 200.0f, 0.0f,
            0.2f, 0.2f, 1.0f, 200.0f, 100.0f, 0.0f};
        
        glInterleavedArrays (GL_C3F_V3F, 0, intertwined);
    }
    
    public void init() {
        glClearColor (0.0f, 0.0f, 0.0f, 0.0f);
        glShadeModel (GL_SMOOTH);
        setupPointers ();
    }
    
    public void display() {
        glClear (GL_COLOR_BUFFER_BIT);
        
        if (derefMethod == DRAWARRAY) 
            glDrawArrays (GL_TRIANGLES, 0, 6);
        else if (derefMethod == ARRAYELEMENT) {
            glBegin (GL_TRIANGLES);
                glArrayElement (2);
                glArrayElement (3);
                glArrayElement (5);
            glEnd ();
        } else if (derefMethod == DRAWELEMENTS) {
            int indices[] = {0, 1, 3, 4};
            
            glDrawElements (GL_POLYGON, 4, GL_UNSIGNED_INT, indices);
        }
        glFlush ();
    }
    
    public void reshape (int w, int h) {
        glViewport (0, 0, w, h);
        glMatrixMode (GL_PROJECTION);
        glLoadIdentity ();
        gluOrtho2D (0.0, (double) w, 0.0, (double) h);
    }
    
    public void mouseClicked(MouseEvent e) {
        if (e.getY() < (getSize().height / 2)) {
            if (setupMethod == POINTER) {
                setupMethod = INTERLEAVED;
                setupInterleave();
            } else if (setupMethod == INTERLEAVED) {
                setupMethod = POINTER;
                setupPointers();
            }
            glutPostRedisplay();
        } else {
            if (derefMethod == DRAWARRAY) 
                derefMethod = ARRAYELEMENT;
            else if (derefMethod == ARRAYELEMENT) 
                derefMethod = DRAWELEMENTS;
            else if (derefMethod == DRAWELEMENTS) 
                derefMethod = DRAWARRAY;
            glutPostRedisplay();
        }
    }
    
    public void mousePressed(MouseEvent e) {
    }
    public void mouseReleased(MouseEvent e) {
    }
    public void mouseEntered(MouseEvent e) {
    }
    public void mouseExited(MouseEvent e) {
    }
    
    void keyboard(char key, int x, int y) {
        switch (key) {
            case 27:
                System.exit(0);
        }
    }
    
    int main() {
        glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
        glutInitWindowSize (350, 350); 
        OGLContext context = jsCreateContextAuto();
        jsInitFunc("init", this, context);
        glutDisplayFunc("display", this, context); 
        glutReshapeFunc("reshape", this, context);
//      glutMouseFunc(mouse);
        addMouseListener(this);
        glutKeyboardFunc("keyboard", this, context);
        return 0;
    }
    
    public static void main(String argv[]) {
        Varray canvas = new Varray();
        canvas.main();
        Frame frame = new Frame("varray");
        frame.add(canvas);
        frame.pack();
        frame.show();
    }
}
