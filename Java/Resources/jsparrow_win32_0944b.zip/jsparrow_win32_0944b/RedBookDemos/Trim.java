/*
 * Copyright (c) 1993-1997, Silicon Graphics, Inc.
 * ALL RIGHTS RESERVED 
 * Permission to use, copy, modify, and distribute this software for 
 * any purpose and without fee is hereby granted, provided that the above
 * copyright notice appear in all copies and that both the copyright notice
 * and this permission notice appear in supporting documentation, and that 
 * the name of Silicon Graphics, Inc. not be used in advertising
 * or publicity pertaining to distribution of the software without specific,
 * written prior permission. 
 *
 * THE MATERIAL EMBODIED ON THIS SOFTWARE IS PROVIDED TO YOU "AS-IS"
 * AND WITHOUT WARRANTY OF ANY KIND, EXPRESS, IMPLIED OR OTHERWISE,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY OR
 * FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL SILICON
 * GRAPHICS, INC.  BE LIABLE TO YOU OR ANYONE ELSE FOR ANY DIRECT,
 * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
 * KIND, OR ANY DAMAGES WHATSOEVER, INCLUDING WITHOUT LIMITATION,
 * LOSS OF PROFIT, LOSS OF USE, SAVINGS OR REVENUE, OR THE CLAIMS OF
 * THIRD PARTIES, WHETHER OR NOT SILICON GRAPHICS, INC.  HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH LOSS, HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE
 * POSSESSION, USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 * US Government Users Restricted Rights 
 * Use, duplication, or disclosure by the Government is subject to
 * restrictions set forth in FAR 52.227.19(c)(2) or subparagraph
 * (c)(1)(ii) of the Rights in Technical Data and Computer Software
 * clause at DFARS 252.227-7013 and/or in similar or successor
 * clauses in the FAR or the DOD or NASA FAR Supplement.
 * Unpublished-- rights reserved under the copyright laws of the
 * United States.  Contractor/manufacturer is Silicon Graphics,
 * Inc., 2011 N.  Shoreline Blvd., Mountain View, CA 94039-7311.
 *
 * OpenGL(R) is a registered trademark of Silicon Graphics, Inc.
 */

/*
 *  trim.c
 *  This program draws a NURBS surface in the shape of a 
 *  symmetrical hill, using both a NURBS curve and pwl
 *  (piecewise linear) curve to trim part of the surface.
 */

/*
 * Trim.java
 * JSparrow version of "trim.c" on Red Book
 *     PFU Limited.  2000
 */

import jsparrow.gl.*;
import java.awt.*;
import java.awt.event.*;

public class Trim extends OGLCanvas {

    float ctlpoints[][][] = new float[4][4][3];

    GLUnurbsObj theNurb;

/*
 *  Initializes the control points of the surface to a small hill.
 *  The control points range from -3 to +3 in x, y, and z
 */
    void init_surface() {
       int u, v;
       for (u = 0; u < 4; u++) {
          for (v = 0; v < 4; v++) {
             ctlpoints[u][v][0] = 2.0f*((float)u - 1.5f);
             ctlpoints[u][v][1] = 2.0f*((float)v - 1.5f);
    
             if ( (u == 1 || u == 2) && (v == 1 || v == 2))
                ctlpoints[u][v][2] = 3.0f;
             else
                ctlpoints[u][v][2] = -3.0f;
          }
       }
    }

    void /*CALLBACK*/ nurbsError(int errorCode) {
       String estring;
    
       estring = gluErrorString(errorCode);
       System.out.println("Nurbs Error: " + estring);
       System.exit (0);
    }
            
/*  Initialize material property and depth buffer.
 */
    void init() {
        float mat_diffuse[] = { 0.7f, 0.7f, 0.7f, 1.0f };
        float mat_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
        float mat_shininess[] = { 100.0f };

        glClearColor (0.0f, 0.0f, 0.0f, 0.0f);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
        glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);

        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_AUTO_NORMAL);
        glEnable(GL_NORMALIZE);

        init_surface();

        theNurb = gluNewNurbsRenderer();
        gluNurbsProperty(theNurb, GLU_SAMPLING_TOLERANCE, 25.0f);
        gluNurbsProperty(theNurb, GLU_DISPLAY_MODE, GLU_FILL);
        gluNurbsCallback(theNurb, GLU_ERROR, 
                         "nurbsError", this);
    }

    void display() {
        float knots[] = {0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f};
        float edgePt[][] = /* counter clockwise */
            {{0.0f, 0.0f}, {1.0f, 0.0f}, {1.0f, 1.0f}, {0.0f, 1.0f}, {0.0f, 0.0f}};
        float curvePt[][] = /* clockwise */ 
            {{0.25f, 0.5f}, {0.25f, 0.75f}, {0.75f, 0.75f}, {0.75f, 0.5f}};
        float curveKnots[] = 
            {0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f};
        float pwlPt[][] = /* clockwise */ 
            {{0.75f, 0.5f}, {0.5f, 0.25f}, {0.25f, 0.5f}};

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glPushMatrix();
        glRotatef(330.0f, 1.0f, 0.0f, 0.0f);
        glScalef (0.5f, 0.5f, 0.5f);

        gluBeginSurface(theNurb);
        gluNurbsSurface(theNurb, 8, knots, 8, knots,
                        4 * 3, 3, ctlpoints, 
                        4, 4, GL_MAP2_VERTEX_3);
        gluBeginTrim (theNurb);
        gluPwlCurve (theNurb, 5, edgePt, 2, GLU_MAP1_TRIM_2);
        gluEndTrim (theNurb);
        gluBeginTrim (theNurb);
        gluNurbsCurve (theNurb, 8, curveKnots, 2, 
                       curvePt, 4, GLU_MAP1_TRIM_2);
        gluPwlCurve (theNurb, 3, pwlPt, 2, GLU_MAP1_TRIM_2);
        gluEndTrim (theNurb);
        gluEndSurface(theNurb);
        
        glPopMatrix();
        glFlush();
    }

    void reshape(int w, int h) {
        glViewport(0, 0, w, h);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective (45.0, (double)w/(double)h, 3.0, 8.0);

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        glTranslatef (0.0f, 0.0f, -5.0f);
    }

    void keyboard(char key, int x, int y) {
        switch (key) {
            case 27:
                System.exit(0);
                break;
        }
    }

/*  Main Loop 
 */
    int main() {
        glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
        glutInitWindowSize (500, 500);
        OGLContext context = jsCreateContextAuto();
        jsInitFunc("init", this, context);
        glutReshapeFunc ("reshape", this, context);
        glutDisplayFunc("display", this, context);
        glutKeyboardFunc("keyboard", this, context);
        return 0;             /* ANSI C requires main to return int. */
    }

    public static void main(String argv[]) {
        Trim canvas = new Trim();
        canvas.main();
        Frame frame = new Frame("trim");
        frame.add(canvas);
        frame.pack();
        frame.show();
    }
}
