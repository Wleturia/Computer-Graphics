/*
 * Copyright (c) 1993-1997, Silicon Graphics, Inc.
 * ALL RIGHTS RESERVED 
 * Permission to use, copy, modify, and distribute this software for 
 * any purpose and without fee is hereby granted, provided that the above
 * copyright notice appear in all copies and that both the copyright notice
 * and this permission notice appear in supporting documentation, and that 
 * the name of Silicon Graphics, Inc. not be used in advertising
 * or publicity pertaining to distribution of the software without specific,
 * written prior permission. 
 *
 * THE MATERIAL EMBODIED ON THIS SOFTWARE IS PROVIDED TO YOU "AS-IS"
 * AND WITHOUT WARRANTY OF ANY KIND, EXPRESS, IMPLIED OR OTHERWISE,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY OR
 * FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL SILICON
 * GRAPHICS, INC.  BE LIABLE TO YOU OR ANYONE ELSE FOR ANY DIRECT,
 * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
 * KIND, OR ANY DAMAGES WHATSOEVER, INCLUDING WITHOUT LIMITATION,
 * LOSS OF PROFIT, LOSS OF USE, SAVINGS OR REVENUE, OR THE CLAIMS OF
 * THIRD PARTIES, WHETHER OR NOT SILICON GRAPHICS, INC.  HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH LOSS, HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE
 * POSSESSION, USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 * US Government Users Restricted Rights 
 * Use, duplication, or disclosure by the Government is subject to
 * restrictions set forth in FAR 52.227.19(c)(2) or subparagraph
 * (c)(1)(ii) of the Rights in Technical Data and Computer Software
 * clause at DFARS 252.227-7013 and/or in similar or successor
 * clauses in the FAR or the DOD or NASA FAR Supplement.
 * Unpublished-- rights reserved under the copyright laws of the
 * United States.  Contractor/manufacturer is Silicon Graphics,
 * Inc., 2011 N.  Shoreline Blvd., Mountain View, CA 94039-7311.
 *
 * OpenGL(R) is a registered trademark of Silicon Graphics, Inc.
 */

/*
 *  surface.c
 *  This program draws a NURBS surface in the shape of a 
 *  symmetrical hill.  The 'c' keyboard key allows you to 
 *  toggle the visibility of the control points themselves.  
 *  Note that some of the control points are hidden by the  
 *  surface itself.
 */

/*
 * Surface.java
 * JSparrow version of "surface.c" on Red Book
 *     PFU Limited.  1998
 */
import jsparrow.gl.*;
import java.awt.*;
import java.awt.event.*;

public class Surface extends OGLCanvas {
    float ctlpoints[][][] = new float[4][4][3];
    boolean showPoints = false;
    
    GLUnurbsObj theNurb;

/*
 *  Initializes the control points of the surface to a small hill.
 *  The control points range from -3 to +3 in x, y, and z
 */
    void init_surface() {
        int u, v;
        for (u = 0; u < 4; u++) {
            for (v = 0; v < 4; v++) {
                ctlpoints[u][v][0] = 2.0f*((float)u - 1.5f);
                ctlpoints[u][v][1] = 2.0f*((float)v - 1.5f);
                
                if ((u == 1 || u == 2) && (v == 1 || v == 2)) {
                    ctlpoints[u][v][2] = 3.0f;
                } else {
                    ctlpoints[u][v][2] = -3.0f;
                }
            }
        }
    }
    
    public void nurbsError(int errorCode) {
        String estring;
        
        estring = gluErrorString(errorCode);
        System.out.println("Nurbs Error: " + estring);
        System.exit(0);
    }
    

/*  Initialize material property and depth buffer.
 */
    public void init() {
        float mat_diffuse[] = { 0.7f, 0.7f, 0.7f, 1.0f };
        float mat_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
        float mat_shininess[] = { 100.0f };
        
        glClearColor (0.0f, 0.0f, 0.0f, 0.0f);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
        glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
        
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_AUTO_NORMAL);
        glEnable(GL_NORMALIZE);

        init_surface();
        
        theNurb = gluNewNurbsRenderer();
        gluNurbsProperty(theNurb, GLU_SAMPLING_TOLERANCE, 25.0f);
        gluNurbsProperty(theNurb, GLU_DISPLAY_MODE, GLU_FILL);
        gluNurbsCallback(theNurb, GLU_ERROR, "nurbsError");
    }
    
    public void display() {
        float knots[] = {0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f};
        int i, j;
        
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        glPushMatrix();
        glRotatef(330.0f, 1.0f ,0.0f ,0.0f);
        glScalef (0.5f, 0.5f, 0.5f);
        
        gluBeginSurface(theNurb);
            gluNurbsSurface(theNurb,
                            8, knots, 8, knots,
                            4 * 3, 3, ctlpoints,
                            4, 4, GL_MAP2_VERTEX_3);
        gluEndSurface(theNurb);
        
        if (showPoints) {
            glPointSize(5.0f);
            glDisable(GL_LIGHTING);
            glColor3f(1.0f, 1.0f, 0.0f);
            glBegin(GL_POINTS);
            for (i = 0; i < 4; i++) {
                for (j = 0; j < 4; j++) {
                    glVertex3f(ctlpoints[i][j][0], 
                               ctlpoints[i][j][1], ctlpoints[i][j][2]);
                }
            }
            glEnd();
            glEnable(GL_LIGHTING);
        }
        glPopMatrix();
        glFlush();
    }
    
    public void reshape(int w, int h) {
        glViewport(0, 0, w, h);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective (45.0d, (double)w/(double)h, 3.0d, 8.0d);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        glTranslatef (0.0f, 0.0f, -5.0f);
    }
    
    public void keyboard(char key, int x, int y) {
        switch (key) {
        case 'c':
        case 'C':
            showPoints = !showPoints;
            glutPostRedisplay();
            break;
        case 27:
            System.exit(0);
            break;
        default:
            break;
        }
    }

    public void main() {
        glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
        glutInitWindowSize (200, 200);
        OGLContext context = jsCreateContextAuto();
        jsInitFunc("init", this, context);
        glutReshapeFunc("reshape", this, context);
        glutDisplayFunc("display", this, context);
        glutKeyboardFunc("keyboard", this, context);
    }

    public static void main(String argv[]) {
        Surface canvas = new Surface();
        canvas.main();
        Frame frame = new Frame("surface");
        frame.add(canvas);
        frame.pack();
        frame.show();
    }
}
