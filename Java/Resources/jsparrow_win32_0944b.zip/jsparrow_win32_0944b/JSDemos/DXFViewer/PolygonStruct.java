/*
 * PolygonStruct.java
 *     PFU Limited.  1999
 *
 *      Author  Keiko Nakayama
 *              Naruki Aruga
 */

public class PolygonStruct {
    int num;
    float vertex[][] = new float[4][3];
    int layernum;
    float normal[] = new float[3];
}
