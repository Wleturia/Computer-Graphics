/*
 * DXFViewer.java
 *     PFU Limited.  1999
 *
 *      Author  Keiko Nakayama
 *              Naruki Aruga
 */
import jsparrow.gl.*;
import java.util.*;
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;

public class DXFViewer extends OGLCanvas 
    implements Runnable, MouseMotionListener {
    /* light */
    double eyePosX = 0.0, eyePosY = 0.0, eyePosZ = 2000.0;
    final float light_diffuse[] = {1.0f, 1.0f, 1.0f, 1.0f};
    final float light_ambient[] = {1.0f, 1.0f, 1.0f, 1.0f};
    final float light_specular[] = {1.0f, 1.0f, 1.0f, 1.0f};
    final float light_position[] = {1.0f, 1.0f, 200.0f, 0.0f};
    final float clearColor[] = {0.0f, 0.1f, 0.5f, 1.0f};

    /* color */
    final float ambient[] = {0.3f, 0.3f, 0.3f, 1.0f};
    final float diffuse[] = {0.8f, 0.8f, 0.8f, 1.0f};
    final float specular[] = {0.0f, 0.0f, 0.0f, 1.0f};
    final float emission[] = {0.0f, 0.0f, 0.0f, 1.0f};
    final float shininess = 0.0f;
    
    /* transformation */
    float rotationX = 0.0f, rotationY = 0.0f;
    float translationX = 0.0f, translationY = 0.0f, translationZ = 0.0f;
    float angleX = 0.0f, angleY = 0.0f;
    int mouseX = 0, mouseY = 0;
    int mouseDX = 0, mouseDY = 0;
    int centerX, centerY;

    /* viewing model */
    final int POLYGON = GL_POLYGON;
    final int WIREFRAME = GL_LINE_LOOP;
    final int POINTS = GL_POINTS;
    final int VIEWINGMODELS[] = {POINTS, WIREFRAME, POLYGON};
    int modelnum = 2;

    /* other */
    float pointSize = 1.0f;
    Thread thread = null;
    boolean mapTexture = false;
    Image image;
    int texName[] = new int[1];
    boolean texture = false;
    DXF dxfdata;

    public DXFViewer(String dxfFilename, String textureFilename) {
        dxfdata = new DXF(dxfFilename);
        if (textureFilename != null) {
            image = getToolkit().getImage(textureFilename);
            this.image = image.getScaledInstance(256, 256, image.SCALE_SMOOTH);
            MediaTracker tracker = new MediaTracker(this);
            tracker.addImage(image, 0);
            try {
                tracker.waitForID(0);
            } catch (InterruptedException e) { }
            mapTexture = true;
        }
        eyePosZ = dxfdata.max * 4;
        jsInitDisplayMode(GLUT_DOUBLE);
        OGLContext context = jsCreateContextAuto(this);
        jsInitFunc("init", this, context);
        jsReshapeFunc("reshape", this, context);
        jsKeyboardFunc("keyboard", this, context);
        addMouseMotionListener(this);
    }

    public void init() {
        glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
        glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
        glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
        glLightfv(GL_LIGHT0, GL_POSITION, light_position);
        glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, 1);
        glEnable(GL_LIGHT0);
        glEnable(GL_LIGHTING);
        glEnable(GL_NORMALIZE);
//        glCullFace(GL_BACK);
//        glEnable(GL_CULL_FACE);
        glShadeModel(GL_SMOOTH);
        glClearColor(clearColor[0], clearColor[1], clearColor[2], clearColor[3]);
        glEnable(GL_DEPTH_TEST);
        glMaterialfv(GL_FRONT, GL_AMBIENT, ambient);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
        glMaterialf(GL_FRONT, GL_SHININESS, shininess);
        glMaterialfv(GL_FRONT, GL_EMISSION, emission);
        glColor3f(1.0f, 1.0f, 1.0f);
        if (mapTexture) {
            byte pixels[] = createTexture(image);
            float planeX[] = {1.0f / (dxfdata.maxX - dxfdata.minX), 0.0f, 0.0f, -dxfdata.minX / (dxfdata.maxX - dxfdata.minX)};
            float planeY[] = {0.0f, -1.0f / (dxfdata.maxY - dxfdata.minY), 0.0f, dxfdata.maxY / (dxfdata.maxY - dxfdata.minY)};

            glGenTextures(1, texName);
            glBindTexture(GL_TEXTURE_2D, texName[0]);
            glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
            glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
//            glEnable(GL_TEXTURE_2D);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, 256, 256, 0, 
                         GL_RGB, GL_UNSIGNED_BYTE, pixels);

            glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
            glTexGenfv(GL_S, GL_OBJECT_PLANE, planeX);
            glEnable(GL_TEXTURE_GEN_S);
            glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
            glTexGenfv(GL_T, GL_OBJECT_PLANE, planeY);
            glEnable(GL_TEXTURE_GEN_T);
        }
    }

    void reshape(int w, int h) {
        centerX = (int) (w * 0.5);
        centerY = (int) (h * 0.5);
        glViewport(0, 0, w, h);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(20.0, 1.0, 1.0, 10000.0);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        gluLookAt(eyePosX, eyePosY, eyePosZ, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
    }

    public void paint(Graphics g) {
        super.paint(g);
        rotationX += angleX;
        rotationY += angleY;
        if (rotationX > 360.0f) {
            rotationX -= 360.0f;
        }
        if (rotationX < -360.0f) {
            rotationX += 360.0f;
        }
        if (rotationY > 360.0f) {
            rotationY -= 360.0f;
        }
        if (rotationY < -360.0f) {
            rotationY += 360.0f;
        }

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glPushMatrix();

        glTranslatef(translationX, translationY, translationZ);
        glRotatef(rotationY, 0.0f, 1.0f, 0.0f);
        glRotatef(rotationX, 1.0f, 0.0f, 0.0f);
        glTranslatef(-dxfdata.modelCenterX, -dxfdata.modelCenterY, -dxfdata.modelCenterZ);

        Enumeration e = dxfdata.vectorPOLYGONS.elements();
        while(e.hasMoreElements()) {
            PolygonStruct p = (PolygonStruct)e.nextElement();
            glBegin(VIEWINGMODELS[modelnum]);
            glNormal3fv(p.normal);
            glVertex3fv(p.vertex[0]);
            glVertex3fv(p.vertex[1]);
            glVertex3fv(p.vertex[2]);
            glVertex3fv(p.vertex[3]);
            glEnd();
        }
        glPopMatrix();

        swapBuffers();        
    }

    public byte[] createTexture(Image image) {
        PixelGrabber pg;
        int pixelsI[];
        byte pixels[];
        int width, height;
        
        width = 256;//image.getWidth(this);
        height = 256;//image.getHeight(this);
        pixelsI = new int[width * height];
        pixels = new byte[width * height * 3];
        pg = new PixelGrabber(image, 0, 0, width, height, pixelsI, 0, width);
        try {
            pg.grabPixels();
        } catch (InterruptedException e) {
        }
        
        for (int i = 0; i < (width * height); i++) {
            pixels[i * 3] = (byte) ((pixelsI[i] & 0x00FF0000) >> 16);
            pixels[i * 3 + 1] = (byte) ((pixelsI[i] & 0x0000FF00) >> 8);
            pixels[i * 3 + 2] = (byte) (pixelsI[i] & 0x000000FF);
        }
        return pixels;
    }

    public void start() {
        if (thread == null) {
            thread = new Thread(this);
            thread.start();
        }
    }

    public void stop() {
        if (thread != null) {
            thread.stop();
            thread = null;
        }
    }

    public void run() {
        while (thread != null) {
            repaint();
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void mouseDragged(MouseEvent e)  {
        mouseDX = mouseX - (e.getX() - centerX);
        mouseDY = mouseY - (e.getY() - centerY);
        translationX = (float)(mouseDX * eyePosZ * -0.002f);
        translationY = (float)(mouseDY * eyePosZ * 0.002f);
    }

    public void mouseMoved(MouseEvent e)  {
        requestFocus();
        
        mouseX = e.getX() - centerX;
        mouseY = e.getY() - centerY;
        angleY = (int)(((double)(mouseX + mouseDX) / 
                        (double)getSize().width) * 40);
        angleX = (int)(((double)(mouseY + mouseDY) / 
                        (double)getSize().height) * 40);
    }

    public void keyboard(char key, int x, int y) {
        switch (key) {
        case 'z':
            translationZ += eyePosZ * 0.1f;
            break;
        case 'Z':
            translationZ -= eyePosZ * 0.1f;
            break;
        case 'v':
        case 'V':
            if (++modelnum > (VIEWINGMODELS.length - 1)) {
                modelnum = 0;
            }
            if (VIEWINGMODELS[modelnum] == POLYGON) {
                glEnable(GL_LIGHTING);
            } else {
                glDisable(GL_LIGHTING);
            }
            break;
        case 'p':
            if (++pointSize > 4.0f) {
                pointSize = 1.0f;
            }
            glPointSize(pointSize);
            break;
        case 'r':
        case 'R':
            dxfdata.reverse();
            break;
        case 't':
        case 'T':
            if (texture) {
                glDisable(GL_TEXTURE_2D);
                texture = false;
            } else {
                glEnable(GL_TEXTURE_2D);
                texture = true;
            }
            break;
        case 27:
            stop();
            System.exit(0);
            break;
        default:
            break;
        }
    }

    public static void main(String argv[]) {
        Image image;
        DXFViewer dv;
        
        if (argv.length == 0) {
            System.out.println("You should specify DXF file.");
            System.exit(-1);
        }
        if (argv.length == 1) {
            dv = new DXFViewer(argv[0], null);
        } else {
            dv = new DXFViewer(argv[0], argv[1]);
        }
        
        dv.setSize(550, 550);
        ControlPanel cp = new ControlPanel(dv);
        Frame frame = new Frame("DXFViewer");
        frame.setSize(660, 550);
        frame.setLayout(new BorderLayout());
        frame.add("West", dv);
        frame.add("Center", cp);
        frame.setVisible(true);
        dv.start();
    }
}

class ControlPanel extends Panel implements ActionListener {
    DXFViewer dv;
    
    public ControlPanel(DXFViewer dv) {
        this.dv = dv;

        /* zoom */
        Button zoomIn = new Button("+");
        Button zoomOut = new Button("-");
        zoomIn.addActionListener(this);
        zoomOut.addActionListener(this);        
        add(new Label("zoom", Label.RIGHT));
        add(zoomIn);
        add(zoomOut);

        /* viewing */
        Button viewing = new Button("change Viewing");
        viewing.addActionListener(this);        
        add(viewing);

        /* pointsize */
        Button pointSize = new Button("change Point Size");
        pointSize.addActionListener(this);      
        add(pointSize);

        /* reverse */
        Button reverse = new Button("reverse");
        reverse.addActionListener(this);        
        add(reverse);

        /* texture */
        Button texture = new Button("map Texture");
        texture.addActionListener(this);
        add(texture);
        if (!dv.mapTexture) {
            texture.setEnabled(false);
        }

        /* exit */
        Button end = new Button("exit");
        end.addActionListener(this);        
        add(end);
    }
    
    public void actionPerformed(ActionEvent e) {
        String s = e.getActionCommand();
        char key = 0;
        
        if (s.equals("+")) key = 'z';
        if (s.equals("-")) key = 'Z';
        if (s.equals("change Viewing")) key = 'v';
        if (s.equals("change Point Size")) key = 'p';
        if (s.equals("reverse")) key = 'r';
        if (s.equals("map Texture")) key = 't';
        if (s.equals("exit")) key = (char)27;
        if (key != 0) dv.keyboard(key, 0, 0);
        
    }
}
    
    
