/*
 * DXF.java
 *     PFU Limited.  1999
 *
 *      Author  Keiko Nakayama
 *              Naruki Aruga
 */
import jsparrow.gl.*;
import java.util.*;
import java.io.*;
import java.net.*;
import java.awt.*;

public class DXF {
    /* DXF */
    Vector vectorPOLYGONS = new Vector();
    Vector vectorlayername = new Vector();

    /* other */
    float max, minX, maxX, minY, maxY, minZ, maxZ;
    float modelCenterX, modelCenterY, modelCenterZ;
    float pointSize = 1.0f;
    float reverse = 1.0f;

    public DXF(String filename) {
        InputStream is;

        try{
            is = new FileInputStream(filename);
        } catch (IOException e) {
            return;
        }
        readDXF(is);
        outerProduct();
    }

    public DXF(URL url) {
        InputStream is;
        try {
            is = url.openStream();
        } catch (IOException e) {
            return;
        }
        readDXF(is);
        outerProduct();
    }

    public void readDXF(InputStream is) {
        int Find_SECTION = 0;
        int Find_ENTITIES = 0;
        int Find_3DFACE = 0;
        PolygonStruct poly = new PolygonStruct();
        String line1, line2;
        DataInputStream dis = new DataInputStream(is);

        try {
            while ((line1 = dis.readLine().trim()) != null){
                if (line1.equals("999")) {
                    dis.readLine().trim();
                    continue;
                } 
                line2 = dis.readLine().trim();
                if (line1.equals("0")) {
                    Find_3DFACE = 0;
                    if (line2.equals("SECTION")) {
                        Find_SECTION = 1;
                    } else if (line2.equals("ENDSEC")) {
                        Find_ENTITIES = 0;
                        Find_SECTION = 0;
                    } else if (line2.equals("EOF")) {
                        break;
                    } else if (line2.equals("3DFACE") && Find_ENTITIES != 0 ) {
                        Find_3DFACE = 1;
                        poly = new PolygonStruct();
                        vectorPOLYGONS.addElement(poly);
                    } else if (line2.equals("POLYLINE")) {
                    }
                                   
                } else if (line1.equals("2") && line2.equals("ENTITIES")) {
                    Find_ENTITIES = 1;
                } else if (Find_3DFACE != 0) {
                    if (line1.equals("8")) {
                        if ((poly.layernum = chk_layer(line2)) == -1) {
                            System.exit(-1);
                        }
                    } else if (line1.equals("10")) {
                        poly.vertex[0][0] = Float.valueOf(line2).floatValue();
                        poly.num = 1;
                    } else if (line1.equals("11")) {
                        poly.vertex[1][0] = Float.valueOf(line2).floatValue();
                        poly.num = 2;
                    } else if (line1.equals("12")) {
                        poly.vertex[2][0] = Float.valueOf(line2).floatValue();
                        poly.num = 3;
                    } else if (line1.equals("13")) {
                        poly.vertex[3][0] = Float.valueOf(line2).floatValue();
                        poly.num = 4;
                    } else if (line1.equals("20")) {
                        poly.vertex[0][1] = Float.valueOf(line2).floatValue();
                        poly.num = 1;
                    } else if (line1.equals("21")) {
                        poly.vertex[1][1] = Float.valueOf(line2).floatValue();
                        poly.num = 2;
                    } else if (line1.equals("22")) {
                        poly.vertex[2][1] = Float.valueOf(line2).floatValue();
                        poly.num = 3;
                    } else if (line1.equals("23")) {
                        poly.vertex[3][1] = Float.valueOf(line2).floatValue();
                        poly.num = 4;
                    } else if (line1.equals("30")) {
                        poly.vertex[0][2] = Float.valueOf(line2).floatValue();
                        poly.num = 1;
                    } else if (line1.equals("31")) {
                        poly.vertex[1][2] = Float.valueOf(line2).floatValue();
                        poly.num = 2;
                    } else if (line1.equals("32")) {
                        poly.vertex[2][2] = Float.valueOf(line2).floatValue();
                        poly.num = 3;
                    } else if (line1.equals("33")) {
                        poly.vertex[3][2] = Float.valueOf(line2).floatValue();
                        poly.num = 4;
                    }
                }
            }
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    public void outerProduct() {
        PolygonStruct f = (PolygonStruct)vectorPOLYGONS.firstElement();
        minX = maxX = f.vertex[0][0];
        minY = maxY = f.vertex[0][1];
        minZ = maxZ = f.vertex[0][2];

        Enumeration e = vectorPOLYGONS.elements();
        while(e.hasMoreElements()) {
            PolygonStruct p = (PolygonStruct)e.nextElement();
            p.normal[0] =
                (p.vertex[1][1]-p.vertex[0][1])*(p.vertex[2][2]-p.vertex[1][2]) - 
                (p.vertex[1][2]-p.vertex[0][2])*(p.vertex[2][1]-p.vertex[1][1]);
            p.normal[1] = 
                (p.vertex[1][2]-p.vertex[0][2])*(p.vertex[2][0]-p.vertex[1][0]) - 
                (p.vertex[1][0]-p.vertex[0][0])*(p.vertex[2][2]-p.vertex[1][2]);
            p.normal[2] = 
                (p.vertex[1][0]-p.vertex[0][0])*(p.vertex[2][1]-p.vertex[1][1]) - 
                (p.vertex[1][1]-p.vertex[0][1])*(p.vertex[2][0]-p.vertex[1][0]);
            for (int i = 0; i < 4; i++) {
                if (minX > p.vertex[i][0]) {
                    minX = p.vertex[i][0];
                }
                if (maxX < p.vertex[i][0]) {
                    maxX = p.vertex[i][0];
                }
                if (minY > p.vertex[i][1]) {
                    minY = p.vertex[i][1];
                }
                if (maxY < p.vertex[i][1]) {
                    maxY = p.vertex[i][1];
                }
                if (minZ > p.vertex[i][2]) {
                    minZ = p.vertex[i][2];
                }
                if (maxZ < p.vertex[i][2]) {
                    maxZ = p.vertex[i][2];
                }
            }
        }
        modelCenterX = (minX + maxX) / 2;
        modelCenterY = (minY + maxY) / 2;
        modelCenterZ = (minZ + maxZ) / 2;
        max = maxX - minX;
        if (max < (maxY - minY)) {
            max = maxY - minY;
        }
        if (max < (maxZ - minZ)) {
            max = maxZ - minZ;
        }
    }

    public void reverse() {
        PolygonStruct f = (PolygonStruct)vectorPOLYGONS.firstElement();
        minX = maxX = f.vertex[0][0];
        minY = maxY = f.vertex[0][1];
        minZ = maxZ = -f.vertex[0][2];

        Enumeration e = vectorPOLYGONS.elements();
        while(e.hasMoreElements()) {
            PolygonStruct p = (PolygonStruct)e.nextElement();
            p.vertex[0][2] *= -1.0f;
            p.vertex[1][2] *= -1.0f;
            p.vertex[2][2] *= -1.0f;
            p.vertex[3][2] *= -1.0f;
            p.normal[0] = 
                (p.vertex[1][1]-p.vertex[0][1])*(p.vertex[2][2]-p.vertex[1][2]) - 
                (p.vertex[1][2]-p.vertex[0][2])*(p.vertex[2][1]-p.vertex[1][1]);
            p.normal[1] = 
                (p.vertex[1][2]-p.vertex[0][2])*(p.vertex[2][0]-p.vertex[1][0]) - 
                (p.vertex[1][0]-p.vertex[0][0])*(p.vertex[2][2]-p.vertex[1][2]);
            p.normal[2] = 
                (p.vertex[1][0]-p.vertex[0][0])*(p.vertex[2][1]-p.vertex[1][1]) - 
                (p.vertex[1][1]-p.vertex[0][1])*(p.vertex[2][0]-p.vertex[1][0]);
            for (int i = 0; i < 4; i++) {
                if (minX > p.vertex[i][0]) {
                    minX = p.vertex[i][0];
                }
                if (maxX < p.vertex[i][0]) {
                    maxX = p.vertex[i][0];
                }
                if (minY > p.vertex[i][1]) {
                    minY = p.vertex[i][1];
                }
                if (maxY < p.vertex[i][1]) {
                    maxY = p.vertex[i][1];
                }
                if (minZ > p.vertex[i][2]) {
                    minZ = p.vertex[i][2];
                }
                if (maxZ < p.vertex[i][2]) {
                    maxZ = p.vertex[i][2];
                }
            }
        }
        modelCenterX = (minX + maxX) / 2;
        modelCenterY = (minY + maxY) / 2;
        modelCenterZ = (minZ + maxZ) / 2;
    }

    public int chk_layer(String name) {
        int hit;

        if (!vectorlayername.contains(name)) {
            vectorlayername.addElement(name);
        }
        hit = vectorlayername.indexOf(name);

        return (hit + 1);
    }
}
