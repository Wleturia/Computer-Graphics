DXFViewer for JSparrow ver. 0.1  Copyright (c) PFU LIMITED  Oct 20 1999
  This program reads modeling data from DXF file and displays on your monitor.

requirement:
  JDK 1.1.5 or later
  JSparrow 0.921b or later

usage:
  >java DXFViewer DXF_file [texture_file]

example:
  >java DXFViewer cone.dxf
  >java DXFViewer cone.dxf mug.gif

control:
  mouse move - turn object
  mouse drug - move object
  'z' key or "+" button
      - zoom in
  'Z' key or "-" button
      - zoom out
  'p', 'P' key or "change Point Size" button
      - change point size
  'v', 'V' key or "change Viewing" button
      - change viewing (POINTS / WIREFRAME / POLYGON)
  'r', 'R' key or "reverse" button
      - reverse object along with z axis
  't', 'T' key or "map Texture" button
      - change texture mapping (ON / OFF)
  Esc key or "exit" button
      - exit
