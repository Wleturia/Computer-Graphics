/*
 * MinOGL2.java
 *     PFU Limited.  1999
 */
import jsparrow.gl.*;
import java.awt.Frame;

public class MinOGL2 {
    public void start() {
        Frame frame = new Frame();
        frame.setSize(300, 300);
        frame.setVisible(true);
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) { }
        
        OGL o = new OGL();
        o.jsInitDisplayMode(o.GLUT_SINGLE | o.GLUT_RGB);
        o.jsCreateContext(frame);

        o.glViewport(0, 0, 300, 300);
        o.glMatrixMode(o.GL_PROJECTION);
        o.glLoadIdentity();
        o.glOrtho(-5.0f, 5.0f, -5.0f, 5.0f, -10.0f, 10.0f);
        o.glMatrixMode(o.GL_MODELVIEW);
        o.glClear(o.GL_COLOR_BUFFER_BIT);
        o.glRectf(-2.5f, -2.5f, 2.5f, 2.5f);
        o.glFlush();
    }
    public static void main(String argv[]) {
        MinOGL2 min = new MinOGL2();
        min.start();
    }
}
