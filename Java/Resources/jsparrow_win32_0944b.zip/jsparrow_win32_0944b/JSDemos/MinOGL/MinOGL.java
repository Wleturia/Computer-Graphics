/*
 * MinOGL.java
 *     PFU Limited.  1999
 */
import jsparrow.gl.*;
import java.awt.Frame;

public class MinOGL extends OGL {
    public void start() {
        Frame frame = new Frame();
        frame.setSize(300, 300);
        frame.setVisible(true);
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) { }
        
        jsInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
        jsCreateContext(frame);

        glViewport(0, 0, 300, 300);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(-5.0f, 5.0f, -5.0f, 5.0f, -10.0f, 10.0f);
        glMatrixMode(GL_MODELVIEW);
        glClear(GL_COLOR_BUFFER_BIT);
        glRectf(-2.5f, -2.5f, 2.5f, 2.5f);
        glFlush();
    }
    public static void main(String argv[]) {
        MinOGL min = new MinOGL();
        min.start();
    }
}
