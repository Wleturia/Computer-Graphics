/*
 * AnimationOGL.java
 *     PFU Limited.  1999
 */
import jsparrow.gl.*;
import java.awt.*;
import java.awt.event.*;

public class AnimationOGL extends OGLPanel implements ActionListener, Runnable,WindowListener {
    Thread thread;
    float angle, direction = 1.0f;

    public void init() {
        float ambient[] = {0.2f, 0.2f, 0.2f, 1.0f};
        float diffuse[] = {1.0f, 1.0f, 1.0f, 1.0f};
        float specular[] = {1.0f, 1.0f, 1.0f, 1.0f};
        float position[] = {1.0f, 1.0f, 1.0f, 0.0f};

        glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
        glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
        glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
        glLightfv(GL_LIGHT0, GL_POSITION, position);

        glFrontFace(GL_CW);
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glEnable(GL_AUTO_NORMAL);
        glEnable(GL_NORMALIZE);
        glEnable(GL_DEPTH_TEST); 
    }

    public void display() {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        float mat[] = new float[] {0.0f, 1.0f, 0.0f, 1.0f};
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat);
        glPushMatrix();
        glRotatef(angle, 0.0f, 1.0f, 0.0f);
        glutSolidTorus(0.9, 1.7, 20, 20);
        glPopMatrix();
        swapBuffers();
    }

    public void reshape(int w, int h) {
        glViewport(0, 0, w, h);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(-3.0f, 3.0f, -3.0f, 3.0f, -10.0f, 10.0f);
        glMatrixMode(GL_MODELVIEW);
    }

    public void actionPerformed(ActionEvent e) {
        direction *= -1;
    }

    public void run() {
        while (thread != null) {
            angle += 5.0f * direction;
            if (angle > 360.0f) angle = 0.0f;
            repaint();
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void windowClosing(WindowEvent e) {
        System.exit(0);
    }
    public void windowActivated(WindowEvent e) {}
    public void windowClosed(WindowEvent e) {}
    public void windowDeactivated(WindowEvent e) {}
    public void windowDeiconified(WindowEvent e) {}
    public void windowIconified(WindowEvent e) {}
    public void windowOpened(WindowEvent e) {}

    void main() {
        jsInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
        OGLContext context = jsCreateContextAuto();
        jsInitFunc("init", this, context);
        jsReshapeFunc("reshape", this, context);
        jsDisplayFunc("display", this, context);

        Button button = new Button("Reverse");
        button.addActionListener(this);
        add(button);

        Frame frame = new Frame("AnimationOGL");
        frame.setSize(300, 300);
        frame.add(this);
        frame.setVisible(true);

        thread = new Thread(this);
        thread.start();

        frame.addWindowListener(this);
    }

    public static void main (String argv[]) {
        AnimationOGL ogl = new AnimationOGL();
        ogl.main();
    }
}
