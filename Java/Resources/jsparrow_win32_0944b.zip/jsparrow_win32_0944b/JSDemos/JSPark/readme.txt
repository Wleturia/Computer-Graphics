JSPark for JSparrow  Copyright (c) PFU LIMITED  Oct 29 1999

requirement:
  JDK 1.1.5 or later
  JSparrow 0.921b or later

usage:
  >java JSPark

control:
  's', 'S' key
      - start / stop
  SPACE key
      - jump
  'k', 'K' key
      - turn left
  'l', 'L' key
      - turn right
  'c', 'C' key
      - change camera position
  Esc key
      - exit
