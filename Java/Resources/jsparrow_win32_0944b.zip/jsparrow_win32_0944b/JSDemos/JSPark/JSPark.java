/*
 * JSPark.java
 *     PFU Limited.  1999
 *
 *      Author  Keiko Nakayama
 */
import jsparrow.gl.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class JSPark extends OGLCanvas implements Runnable {
    final int FRAMESIZE = 600;

    double direction = 0.0;
    float x = 0.0f, y = 3.0f, z = 0.0f;
    Thread thread;
    int width, height;
    Image image;
    int camera = 0;
    int jump = 0;
    float v, a, t;
    
    public void init() {
        float ambient[] = {0.2f, 0.2f, 0.2f, 1.0f};
        float diffuse[] = {1.0f, 1.0f, 1.0f, 1.0f};
        float specular[] = {1.0f, 1.0f, 1.0f, 1.0f};
        float position[] = {1.0f, 1.0f, 1.0f, 0.0f};

        glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
        glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
        glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
        glLightfv(GL_LIGHT0, GL_POSITION, position);

        glFrontFace(GL_CW);
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glEnable(GL_AUTO_NORMAL);
        glEnable(GL_NORMALIZE);
        glEnable(GL_DEPTH_TEST); 
        
        glClearColor(0.0f, 0.3f, 0.7f, 1.0f);
        image = getToolkit().getImage("texture.gif");
        MediaTracker tracker = new MediaTracker(this);
        tracker.addImage(image, 0);
        try {
            tracker.waitForID(0);
        } catch (InterruptedException e) { }
        setTexture(createTexture(image));
    }

    public void display() {
        float mat_white[] = {1.0f, 1.0f, 1.0f, 1.0f};
        float mat_red[] = {1.0f, 0.0f, 0.0f, 1.0f};
        float mat_black[] = {0.0f, 0.0f, 0.0f, 1.0f};
        float mat_green[] = {0.3f, 1.0f, 0.3f, 1.0f};
        float mat_yellow[] = {1.0f, 1.0f, 0.0f, 1.0f};
        float mat_orange[] = {1.0f, 0.2f, 0.0f, 1.0f};

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glPushMatrix();

        /* setProjection */
        if (camera == 2) {
            glMatrixMode(GL_PROJECTION);
            glLoadIdentity();
            gluPerspective(70.0, 1.0, 0.5, 100.0);
            gluLookAt(x, z + 0.5, y, 
                      x + (Math.cos(direction * (Math.PI / 180)) * 8.0), 0.0f, y + (Math.sin(direction * (Math.PI / 180)) * 8.0),
                      0.0, 1.0, 0.0);
            glMatrixMode(GL_MODELVIEW);
        }

        /* Earth */
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_white);
        drawEarth();

        /* Car */
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_red);
        glPushMatrix();
        glTranslatef(x, z, y);
        glRotatef((float)(90.0 - direction), 0.0f, 1.0f, 0.0f);
        drawBunchoh();
        glPopMatrix();

        /* Tree */
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_green);
        glPushMatrix();
        glTranslatef(3.7f, 0.0f, -3.7f);
        drawTree();
        glPopMatrix();

        glPopMatrix();

        /* Pole */
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_yellow);
        glPushMatrix();
        glTranslatef(-2.8f, 0.0f, -0.1f);
        glRotatef(120.0f, 0.0f, 1.0f, 0.0f);
        glTranslatef(0.0f, 0.0f, 0.2f);
        drawPole();
        glTranslatef(1.0f, 0.0f, 0.0f);
        drawPole();
        glTranslatef(1.0f, 0.0f, 0.0f);
        drawPole();
        glPopMatrix();

        /* Gate */
        glPushMatrix();
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_orange);
        glTranslatef(0.8f, 0.1f, 0.8f);
        glRotatef(-40.0f, 0.0f, 1.0f, 0.0f);
        drawGate();
        glPopMatrix();

        swapBuffers();
    }
    
    public void drawCar() {
        glPushMatrix();
        glutSolidSphere(0.4, 20, 20);
        glPopMatrix();
    }
    
    public void drawEarth() {
        float normals[] = new float[] {0, 0, 1};
        int faces[] = new int[] {0, 1, 2, 3};
        float vertices[][] = new float[][] {{-0.5f, -0.5f, 0.0f},{0.5f, -0.5f, 0.0f},{0.5f, 0.5f, 0.0f},{-0.5f, 0.5f, 0.0f}};

        glPushMatrix();
        glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
        glScalef(9.0f, 9.0f, 9.0f);
/*      glBegin(GL_POLYGON);
            glNormal3fv(normals);
            glVertex3fv(vertices[faces[0]]);
            glVertex3fv(vertices[faces[1]]);
            glVertex3fv(vertices[faces[2]]);
            glVertex3fv(vertices[faces[3]]);
        glEnd();
*/
        glEnable(GL_TEXTURE_2D);
        glBegin(GL_POLYGON);
            glNormal3fv(normals);
            glTexCoord2f(0.0f, 1.0f);
            glVertex3fv(vertices[faces[0]]);
            glTexCoord2f(1.0f, 1.0f);
            glVertex3fv(vertices[faces[1]]);
            glTexCoord2f(1.0f, 0.0f);
            glVertex3fv(vertices[faces[2]]);
            glTexCoord2f(0.0f, 0.0f);
            glVertex3fv(vertices[faces[3]]);
        glEnd();
        glDisable(GL_TEXTURE_2D);

        glPopMatrix();
    }
    
    public void drawTree() {
        float color_brawn[] = {0.6f, 0.3f, 0.0f, 1.0f};

        glPushMatrix();
        
        glTranslatef(0.0f, 2.5f, 0.0f);
        glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
        glTranslatef(0.0f, 0.0f, -0.9f);
        glutSolidCone(0.5f, 0.5f, 20, 20);
        glTranslatef(0.0f, 0.0f, -0.6f);
        glutSolidCone(0.7f, 0.7f, 20, 20);
        glTranslatef(0.0f, 0.0f, -0.6f);
        glutSolidCone(0.9f, 0.9f, 20, 20);
                glMaterialfv(GL_FRONT, GL_DIFFUSE, color_brawn);
        glTranslatef(0.0f, 0.0f, -0.6f);
        glutSolidCone(0.05f, 2.0f, 20, 20);
        
        glPopMatrix();
    }

    public void drawPole() {
        glPushMatrix();
        
        glScalef(0.7f, 0.7f, 0.7f);
        glPushMatrix();
        glScalef(1.0f, 0.2f, 1.0f);
        glutSolidCube(0.7);
        glPopMatrix();
        glTranslatef(0.0f, 0.0f, 0.0f);
        glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
        glutSolidCone(0.3, 1.0, 20, 20);

        glPopMatrix();
    }

    public void drawGate() {
        glPushMatrix();
        glutSolidTorus(0.25f, 1.0f, 4, 20);
        glPopMatrix();
    }

    public void drawBunchoh() {
        float mat_white[] = {1.0f, 1.0f, 1.0f, 1.0f};
        float mat_red[] = {1.0f, 0.0f, 0.0f, 1.0f};
        float mat_black[] = {0.0f, 0.0f, 0.0f, 1.0f};

        glPushMatrix();
        
        glTranslatef(0.0f, 0.25f, 0.0f);
        glScalef(0.3f, 0.3f, 0.3f);

        glPushMatrix();
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_red);
        glTranslatef(0.0f, 0.6f, 0.6f);
        glRotatef(-15.0f, 1.0f, 0.0f, 0.0f);
        glutSolidCone(0.5, 1.0, 20, 20);
        glPopMatrix();

        glPushMatrix();
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_white);
        glScalef(1.0f, 1.5f, 1.0f);
        glutSolidSphere(1.0, 20, 20);
        glPopMatrix();

        glPushMatrix();
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_black);
        glTranslatef(0.75f, 0.8f, 0.2f);
        glutSolidSphere(0.14, 20, 20);
        glPopMatrix();
        
        glPushMatrix();
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_black);
        glTranslatef(-0.75f, 0.8f, 0.2f);
        glutSolidSphere(0.14, 20, 20);
        glPopMatrix();

        glPushMatrix();
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_white);
        glTranslatef(0.0f, -0.5f, -0.7f);
        glBegin(GL_POLYGON);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(0.5f, -0.4f, -2.0f);
        glVertex3f(-0.5f, -0.4f, -2.0f);
        glEnd();
        glPopMatrix();

        glPopMatrix();
    }
    public void run() {
        while (thread != null) {
            x += Math.cos(direction * Math.PI / 180) * 0.02;
            y += Math.sin(direction * Math.PI / 180) * 0.02;
            if (x > 4.2f) x = 4.2f;
            if (x < -4.2f) x = -4.2f;
            if (y > 4.2f) y = 4.2f;
            if (y < -4.2f) y = -4.2f;
            
            if (jump != 0) {
                t = (float)(200 - jump);
                                a = 1.5f / (100 * 100);
                                v = a * 100 * 2;
                z = v * t - a * t * t;
                if (jump-- == 0) z = 0.0f;
            }
//          System.out.print(jump + ",");
//          System.out.print("," + z + " ");
            
            glutPostRedisplay();
            try {
                Thread.sleep(10);
            } catch(InterruptedException e) {}
        }
    }
    
    public synchronized void reshape(int w, int h) {
        glViewport(0, 0, w, h);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
//        glOrtho(-5.0f, 5.0f, -5.0f, 5.0f, -10.0f, 10.0f);
        gluPerspective(70.0, 1.0, 0.5, 100.0);

        switch (camera) {
            case 0: gluLookAt(-2.0, 3.0, 8.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0); break;
            case 1: gluLookAt(0.0, 8.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -1.0); break;
            case 2: gluLookAt(x, 0.5, y, 
                              x + (Math.cos(direction * (Math.PI / 180)) * 8.0), 0.0f, y + (Math.sin(direction * (Math.PI / 180)) * 8.0),
                              0.0, 1.0, 0.0); break;
            default: gluLookAt(-2.0, 3.0, 8.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0); break;
        }

        glMatrixMode(GL_MODELVIEW);
    }
    
    void keyboard (char key, int x, int y) {
        switch (key) {
            case 'k': direction -= 10.0; break;
            case 'l': direction +=10.0; break;
            case ' ': 
                if (thread != null && jump == 0) jump = 200; break;
            case 's': 
                if (thread == null) {
                    thread = new Thread(this);
                    thread.start();
                } else {
                    thread .stop();
                    thread = null;
                }
                break;

            case 'c': 
                if (camera++ > 2) camera = 0;
                reshape(FRAMESIZE, FRAMESIZE);
                break;

            case 27: System.exit(0); break;

            default: break;
        }
        glutPostRedisplay();
    }

    int main() {
        glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
        OGLContext context = jsCreateContextAuto();
        glutInitWindowSize(FRAMESIZE, FRAMESIZE);
        glutReshapeFunc("reshape", this, context);
        glutDisplayFunc("display", this, context);
        glutKeyboardFunc("keyboard", this, context);
        jsInitFunc("init", this, context);
        return 0;
    }

    public static void main (String argv[]) {
        JSPark canvas = new JSPark();
        canvas.main();
        Frame frame = new Frame("JSPark");
        frame.add(canvas);
        frame.pack();
        frame.show();
    }

     byte[] createTexture(Image image) {
        PixelGrabber pg;
        byte pixels[];
        int pixelsI[];
        
        width = image.getWidth(this);
        height = image.getHeight(this);
        pixelsI = new int[width * height];
        pixels = new byte[width * height * 3];
        pg = new PixelGrabber(image, 0, 0, width, height, pixelsI, 0, width);
        try {
            pg.grabPixels();
        } catch (InterruptedException e) {
        }
        
        for (int i = 0; i < (width * height); i++) {
            pixels[i * 3] = (byte) ((pixelsI[i] & 0x00FF0000) >> 16);
            pixels[i * 3 + 1] = (byte) ((pixelsI[i] & 0x0000FF00) >> 8);
            pixels[i * 3 + 2] = (byte) (pixelsI[i] & 0x000000FF);
        }
        return pixels;
    }

    void setTexture(byte pixels[]) {
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8/*3*/, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, pixels);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    }
}

/*
import java.applet.Applet;

public class Teapot extends Applet {
    public void init() {
        TeapotCanvas canvas = new TeapotCanvas();
        canvas.main();
        add(canvas);
    }
}
*/