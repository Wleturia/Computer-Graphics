/*
 * Objects.java
 *     PFU Limited.  1999
 *
 *      Author  Keiko Nakayama
 *              Naruki Aruga
 */
import jsparrow.gl.*;
import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

class ObjectsPanel extends OGLPanel {
    float cubeX = 0.0f;
    float cubeY = 0.0f;
    float sphereX = 0.0f;
    float sphereY = 0.0f;
    float torusX = 0.0f;
    float torusY = 0.0f;
    float teapotX = 0.0f;
    float teapotY = 0.0f;
    float hedronX = 0.0f;
    float hedronY = 0.0f;
    boolean cube = true, sphere = true, torus = false, teapot = false, hedron = false;
    boolean bg = true;
    float colorR = 0.0f, colorG = 0.0f, colorB = 0.0f;
    float dR = 0.01f, dG = 0.02f, dB = 0.03f;
    
    public ObjectsPanel() {
        jsInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
        OGLContext context = jsCreateContextAuto();
        jsInitFunc("init", this, context);
        jsDisplayFunc("display", this, context);
        jsReshapeFunc("reshape", this, context);
    }
    
    public void init() {
        float light_position[] = {1.0f, 1.0f, 2.0f, 0.0f};
        glLightfv(GL_LIGHT0, GL_POSITION, light_position);
        glEnable(GL_LIGHT0);
        glEnable(GL_LIGHTING);
        glEnable(GL_NORMALIZE);
        glCullFace(GL_BACK);
        glEnable(GL_CULL_FACE);
        glShadeModel(GL_SMOOTH);
        glEnable(GL_DEPTH_TEST);
    }
    
    public void reshape(int w, int h) {
        glViewport(0, 0, w, h);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(50.0, 1.0, 1.0, 100.0);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        gluLookAt(0.0, 0.0, 10.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
    }
    
    public void display() {
        colorR += dR;
        colorG += dG;
        colorB += dB;
        if (bg) glClearColor(colorR, colorG, colorB, 1.0f);
        else glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        if (colorR > 1.0f || colorR < 0.0f) dR *= -1.0f;
        if (colorG > 1.0f || colorG < 0.0f) dG *= -1.0f;
        if (colorB > 1.0f || colorB < 0.0f) dB *= -1.0f;
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        if (cube) drawCube();
        if (sphere) drawSphere();
        if (torus) drawTorus();
        if (teapot) drawTeapot();
        if (hedron) drawHedron();
        swapBuffers();
    }
    
    public void drawCube() {
        float normals[][] = {{0, 0, 1},{1, 0, 0},{0, 0, -1},
                             {-1, 0, 0},{0, 1, 0},{0, -1, 0}};
        int faces[][] = {{0, 1, 2, 3},{1, 7, 6, 2},{4, 5, 6, 7},
                         {0, 3, 5, 4},{2, 6, 5, 3},{0, 4, 7, 1}};
        float vertices[][] = {{-1.0f, -1.0f, 1.0f},{1.0f, -1.0f, 1.0f},
                              {1.0f, 1.0f, 1.0f},{-1.0f, 1.0f, 1.0f},
                              {-1.0f, -1.0f, -1.0f},{-1.0f, 1.0f, -1.0f},
                              {1.0f, 1.0f, -1.0f},{1.0f, -1.0f, -1.0f}};
        float diffuse[] = {1.0f, 0.6f, 0.0f, 1.0f};
        float specular[] = {0.3f, 0.3f, 0.3f, 1.0f};
        
        glPushMatrix();
        cubeX += 10.0f;
        cubeY += 10.0f;
        glRotatef(cubeX, 1.0f, 0.0f, 0.0f);
        glTranslatef(0.0f, 0.0f, 2.5f);
        glRotatef(cubeY, 0.0f, 1.0f, 0.0f);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
        glMaterialf(GL_FRONT, GL_SHININESS, 1.0f);
        for (int i = 0; i < faces.length; i++) {
            glBegin(GL_POLYGON);
                glNormal3fv(normals[i]);
                glVertex3fv(vertices[faces[i][0]]);
                glVertex3fv(vertices[faces[i][1]]);
                glVertex3fv(vertices[faces[i][2]]);
                glVertex3fv(vertices[faces[i][3]]);
            glEnd();
        }
        glPopMatrix();
    }
    
    public void drawSphere() {
        float diffuse[] = {0.8f, 0.0f, 0.0f, 1.0f};
        float shininess[] = {100.0f};
        float specular[] = {1.0f, 1.0f, 1.0f, 1.0f};
        glPushMatrix();
        sphereX += 5.0f;
        sphereY += 10.0f;
        glRotatef(sphereX, 1.0f, 0.0f, 0.0f);
        glRotatef(sphereY, 0.0f, 1.0f, 0.0f);
        glTranslatef(0.0f, 2.0f, 2.0f);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
        glMaterialfv(GL_FRONT, GL_SHININESS, shininess);
        glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
        glutSolidSphere(1.0, 20, 20); //auxSolidSphere(1.0);
        glPopMatrix();
    }

    public void drawTorus() {
        float diffuse[] = {0.3f, 0.0f, 0.8f, 1.0f};
        float specular[] = {1.0f, 1.0f, 1.0f, 1.0f};
        glPushMatrix();
        torusX += 10.0f;
        torusY += 10.0f;
        glRotatef(torusX, 1.0f, 0.0f, 0.0f);
        glRotatef(torusY, 0.0f, 1.0f, 0.0f);
        glTranslatef(0.0f, 2.0f, 2.0f);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
        glMaterialf(GL_FRONT, GL_SHININESS, 100.0f);
        glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
        glutSolidTorus(0.5, 1.0, 20, 20);
        glPopMatrix();
    }

    public void drawTeapot() {
        float diffuse[] = {0.5f, 0.8f, 0.3f, 1.0f};
        float specular[] = {1.0f, 1.0f, 1.0f, 1.0f};
        glPushMatrix();
        teapotX += 10.0f;
        teapotY += 10.0f;
        glRotatef(teapotY, 0.0f, 1.0f, 0.0f);
        glTranslatef(3.0f, 0.0f, 0.0f);
        glRotatef(teapotX, 1.0f, 0.0f, 0.0f);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
        glMaterialf(GL_FRONT, GL_SHININESS, 100.0f);
        glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
        glFrontFace(GL_CW);
        glutSolidTeapot(0.8);
        glFrontFace(GL_CCW);
        glPopMatrix();
    }

    public void drawHedron() {
        float diffuse[] = {0.3f, 0.8f, 0.9f, 1.0f};
        float specular[] = {1.0f, 1.0f, 1.0f, 1.0f};
        glPushMatrix();
        hedronX += 10.0f;
        hedronY += 5.0f;
        glRotatef(hedronY, 0.0f, 1.0f, 0.0f);
        glTranslatef(2.5f, 0.0f, 0.0f);
        glRotatef(hedronX, 1.0f, 0.0f, 0.0f);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
        glMaterialf(GL_FRONT, GL_SHININESS, 100.0f);
        glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
        glutSolidDodecahedron(/*0.8*/);
        glPopMatrix();
    }
}

public class Objects extends Applet implements Runnable, ItemListener, WindowListener {
    ObjectsPanel panel;
    Thread thread = null;
    Checkbox cube, sphere, torus, teapot, hedron;
    Checkbox bg;
    
    public void init() {
        panel = new ObjectsPanel();
        setLayout(new BorderLayout());
        add("Center", panel);
        cube = new Checkbox("cube", true);
        panel.add(cube);
        cube.addItemListener(this);
        sphere = new Checkbox("sphere", true);
        panel.add(sphere);
        sphere.addItemListener(this);
        torus = new Checkbox("torus", false);
        panel.add(torus);
        torus.addItemListener(this);
        teapot = new Checkbox("teapot", false);
        panel.add(teapot);
        teapot.addItemListener(this);
        hedron = new Checkbox("hedron", false);
        panel.add(hedron);
        hedron.addItemListener(this);
        bg = new Checkbox("bg", true);
        panel.add(bg);
        bg.addItemListener(this);
    }
    
    public void start() {
        if (thread == null) {
            thread = new Thread(this);
            thread.start();
        }
    }

    public void stop() {
        if (thread != null) {
            thread.stop();
            thread = null;
        }
    }
    

    public void run() {
        while (thread != null) {
            panel.repaint();
            
            try {
                Thread.sleep(10);
            } catch(InterruptedException e) {
            }
        }
    }

    public void itemStateChanged(ItemEvent e)  {
        if(e.getItem().toString().equals("cube")){
            panel.cube = !panel.cube;
        } else if (e.getItem().toString().equals("sphere")) {
            panel.sphere = !panel.sphere;
        } else if (e.getItem().toString().equals("torus")) {
            panel.torus = !panel.torus;
        } else if (e.getItem().toString().equals("teapot")) {
            panel.teapot = !panel.teapot;
        } else if (e.getItem().toString().equals("hedron")) {
            panel.hedron = !panel.hedron;
        } else if (e.getItem().toString().equals("bg")) {
            panel.bg = !panel.bg;
        }
    }
    
    public void windowClosing(WindowEvent e) {
        System.exit(0);
    }
    public void windowActivated(WindowEvent e) {}
    public void windowClosed(WindowEvent e) {}
    public void windowDeactivated(WindowEvent e) {}
    public void windowDeiconified(WindowEvent e) {}
    public void windowIconified(WindowEvent e) {}
    public void windowOpened(WindowEvent e) {}

    public static void main(String argv[]) {
        Objects objects = new Objects();
        objects.init();
        Frame frame = new Frame("Objects");
        frame.setSize(400, 400);
        frame.add(objects);
        frame.setVisible(true);
        frame.addWindowListener(objects);
        objects.start();
    }
}



