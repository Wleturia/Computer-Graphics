/*
 * Teapot.java
 *     PFU Limited.  1998
 */
import java.applet.Applet;

public class Teapot extends Applet {
    public void init() {
        TeapotCanvas canvas = new TeapotCanvas();
        canvas.main();
        add(canvas);
    }
}
