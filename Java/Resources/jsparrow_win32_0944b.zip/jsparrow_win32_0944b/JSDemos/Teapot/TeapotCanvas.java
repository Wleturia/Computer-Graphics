/*
 * TeapotCanvas.java
 *     PFU Limited.  1999
 */
import jsparrow.gl.*;
import java.awt.*;
import java.awt.event.*;

public class TeapotCanvas extends OGLCanvas {
    public void init() {
        float ambient[] = {0.2f, 0.2f, 0.2f, 1.0f};
        float diffuse[] = {1.0f, 1.0f, 1.0f, 1.0f};
        float specular[] = {1.0f, 1.0f, 1.0f, 1.0f};
        float position[] = {1.0f, 1.0f, 1.0f, 0.0f};

        glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
        glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
        glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
        glLightfv(GL_LIGHT0, GL_POSITION, position);

        glFrontFace(GL_CW);
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glEnable(GL_AUTO_NORMAL);
        glEnable(GL_NORMALIZE);
        glEnable(GL_DEPTH_TEST); 
    }

    public void display() {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        float mat[] = {1.0f, 0.0f, 0.0f, 1.0f};
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat);
        glutSolidTeapot(1.0);
        glFlush();
    }
    
    public synchronized void reshape(int w, int h) {
        glViewport(0, 0, w, h);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(-3.0f, 3.0f, -3.0f, 3.0f, -10.0f, 10.0f);
        glMatrixMode(GL_MODELVIEW);
    }
    
    public void keyboard(char key, int x, int y) {
        switch (key) {
            case 27:
                System.exit(0);
        }
    }

    int main() {
        jsInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
        OGLContext context = jsCreateContextAuto();
        glutInitWindowSize(200, 200);
        jsReshapeFunc("reshape", this, context);
        jsDisplayFunc("display", this, context);
        jsKeyboardFunc("keyboard", this, context);
        jsInitFunc("init", this, context);
        return 0;
    }

    public static void main (String argv[]) {
        TeapotCanvas canvas = new TeapotCanvas();
        canvas.main();
        Frame frame = new Frame("teapot");
        frame.add(canvas);
        frame.pack();
        frame.show();
    }
}
