/*
 * MultiThread.java
 *     PFU Limited.  1999
 *
 *      Author  Keiko Nakayama
 *              Naruki Aruga
 */
import jsparrow.gl.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;

public class MultiThread extends Applet implements WindowListener {
    Canvas c;
    RectThread t1, t2;
    
    public MultiThread() {
        float color[][] = {{0.0f, 0.7f, 0.0f}, {0.7f, 0.0f, 0.0f}};

        c = new Canvas();
        c.setSize(300, 300);
        c.setBackground(Color.white);
        t1 = new RectThread(c, 7.0f, 7.0f, 200, color[0]);
        t2 = new RectThread(c, -5.0f, -5.0f, 300, color[1]);
    }

    public void init() {
        add(c);
    }

    public void start() {
        t1.start();
        t2.start();
    }

    public void stop() {
        t1.stop();
        t2.stop();
    }

    public void main() {
        Frame frame = new Frame("MultiThread");
        frame.addWindowListener(this);
        frame.add(c);
        frame.pack();
        frame.show();
    }

    public static void main(String argv[]) {
        MultiThread m = new MultiThread();
        m.main();
        m.start();
    }

    public void windowClosing(WindowEvent e) {
        System.exit(0);
    }
    public void windowActivated(WindowEvent e) {}
    public void windowClosed(WindowEvent e) {}
    public void windowDeactivated(WindowEvent e) {}
    public void windowDeiconified(WindowEvent e) {}
    public void windowIconified(WindowEvent e) {}
    public void windowOpened(WindowEvent e) {}
}

class RectThread implements Runnable, OGLConstants {
    OGL o = new OGL();
    OGLContext con;
    Thread thread;
    Canvas canvas;
    float step, distance, color[];
    float angle = 0.0f;
    int time;
    boolean f = false;

    RectThread(Canvas canvas, float step, float distance, 
                                    int time, float color[]) {
        this.canvas = canvas;
        this.step = step;
        this.distance = distance;
        this.time = time;
        this.color = color;
        o.jsInitDisplayMode(GLUT_SINGLE);
    }

    void start() {
        if (thread == null) {
            thread = new Thread(this);
            thread.start();
        }
    }

    void stop() {
        if (thread != null) {
            thread.stop();
            thread = null;
        }
    }

    void init() {
        o.glViewport(0, 0, 300, 300);
        o.glMatrixMode(GL_PROJECTION);
        o.glLoadIdentity();
        o.glOrtho(-10.0f, 10.0f, -10.0f, 10.0f, -10.0f, 10.0f);
        o.glMatrixMode(GL_MODELVIEW);
    }

    void draw() {
        o.glPushMatrix();
        o.glRotatef(angle, 0.0f, 0.0f, 1.0f);
        o.glTranslatef(distance, 0.0f, 0.0f);
        o.glColor3f(1.0f, 1.0f, 1.0f);
        o.glRectf(-1.0f, -1.0f, 1.0f, 1.0f);
        o.glPopMatrix();
        
        angle += step;
        if (angle > 360.0f) {
            angle = 0.0f;
        }
        o.glPushMatrix();
        o.glRotatef(angle, 0.0f, 0.0f, 1.0f);
        o.glTranslatef(distance, 0.0f, 0.0f);
        o.glColor3fv(color);
        o.glRectf(-1.0f, -1.0f, 1.0f, 1.0f);
        o.glPopMatrix();
        o.glFlush();
    }

    public void run() {
        while (thread != null) {
            if (con == null) {
                con = o.jsCreateContext(canvas);
                if (con != null) {
                    init();
                    f = true;
                }
            }
            if (f && o.jsMakeCurrent(canvas, con)) {
                draw();
                o.jsMakeCurrent(null, null);
            }
            try {
                Thread.sleep(time);
            } catch (InterruptedException e) {
            }
        }
    }
}



