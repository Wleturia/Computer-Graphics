/*
 * Projections.java
 *     PFU Limited.  1999
 *
 *      Author  Keiko Nakayama
 *              Naruki Aruga
 */
import jsparrow.gl.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

public class Projections extends Observable {
    Thread thread;
    
    public static void main(String argv[]) {
        Projections pro = new Projections();
        int mode[] = {View.TOP, View.NONE, View.FRONT, View.SIDE};
        double eye[][] = new double[][] {{0.0, 3.0, 0.0}, {2.0, 2.0, 2.0}, {0.0, 0.0, 3.0}, {3.0, 0.0, 0.0}};
        double up[][] = new double[][] {{0.0, 0.0, -1.0}, {0.0, 1.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 1.0, 0.0}};
        View view[] = new View[eye.length];

        Frame frame = new Frame("View");
        frame.setLayout(new FlowLayout());
        for (int i = 0; i < view.length; i++) {
            view[i] = new View(eye[i], up[i], mode[i], pro);
            if (i == 0) {
                view[i].main(null);
            } else {
                view[i].main(view[i - 1]);
            }
            pro.addObserver(view[i]);
            frame.add(view[i]);
        }
        frame.setSize(430, 450);
        frame.show();
    }

    public void changed() {
        setChanged();
        notifyObservers();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
        }
    }
}

class View extends OGLCanvas implements Observer, MouseMotionListener {
    double eye[], up[];
    Projections pro;
    boolean createList = false;
    OGLContext context;
    static int list;
    static float angleX, angleY, angleZ;
    int mode;
    static final int NONE = 0, TOP = 1, FRONT = 2, SIDE = 3;
    static final String modeString[] = {"", "TOP", "FRONT", "SIDE"};
    int currentX, currentY;

    public void update(Observable o, Object obj) {
        repaint();
    }
    
    public View(double eye[], double up[], int mode, Projections pro) {
        this.eye = eye;
        this.up = up;
        this.pro = pro;
        this.mode = mode;
        addMouseMotionListener(this);
    }
    
    public void init() {
        glClearColor (0.0f, 0.0f, 0.0f, 0.0f);
        glShadeModel (GL_FLAT);
        if (createList) {
            list = glGenLists(1);
            keyboard('c', 0, 0);
        }
    }
    
    public void reshape (int w, int h) {
        glViewport (0, 0, w, h); 
        glMatrixMode (GL_PROJECTION);
        glLoadIdentity ();
        glFrustum (-1.0, 1.0, -1.0, 1.0, 1.5, 20.0);
        glMatrixMode (GL_MODELVIEW);
        glLoadIdentity ();
        gluLookAt (eye[0], eye[1], eye[2], 0.0, 0.0, 0.0, up[0], up[1], up[2]);
    }
    
    public void display() {
        glClear (GL_COLOR_BUFFER_BIT);
        drawAxis();
        draw();
        swapBuffers();
    }

    public void draw() {
        glRotatef(angleX, 1.0f, 0.0f, 0.0f);
        glRotatef(angleY, 0.0f, 1.0f, 0.0f);
        glRotatef(angleZ, 0.0f, 0.0f, 1.0f);
        glCallList(list);
    }

    public void paint(Graphics g) {
        super.paint(g);
        g.setColor(Color.yellow);
        g.drawString(modeString[mode], 4, 10);
    }
    
    public void drawAxis() {
        float identity[][] = {{1.0f, 0.0f, 0.0f}, {0.0f, 1.0f, 0.0f}, {0.0f, 0.0f, 1.0f}};
        glPushMatrix();
        glLoadIdentity ();
        gluLookAt (eye[0], eye[1], eye[2], 0.0, 0.0, 0.0, up[0], up[1], up[2]);

        glColor3f(0.5f, 0.0f, 0.0f);
        glBegin(GL_LINES);
            glVertex3f(-10.0f, 0.0f, 0.0f);
            glVertex3f(10.0f, 0.0f, 0.0f);
        glEnd();
        glPushMatrix();
        glTranslatef(1.7f, 0.0f, 0.0f);
        glutSolidSphere(0.05, 5, 5);
        glPopMatrix();

        glColor3f(0.0f, 0.5f, 0.0f);
        glBegin(GL_LINES);
            glVertex3f(0.0f, -10.0f, 0.0f);
            glVertex3f(0.0f, 10.0f, 0.0f);
        glEnd();
        glPushMatrix();
        glTranslatef(0.0f, 1.7f, 0.0f);
        glutSolidSphere(0.05, 5, 5);
        glPopMatrix();

        glColor3f(0.0f, 0.0f, 0.5f);
        glBegin(GL_LINES);
            glVertex3f(0.0f, 0.0f, -10.0f);
            glVertex3f(0.0f, 0.0f, 10.0f);
        glEnd();
        glPushMatrix();
        glTranslatef(0.0f, 0.0f, 1.7f);
        glutSolidSphere(0.05, 5, 5);
        glPopMatrix();

        glPopMatrix();
    }

    public void mouseDragged(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        
        angleX = 0;
        angleY = 0;
        angleZ = 0;

        switch (mode) {
            case TOP:
                angleZ = currentX - x;
                angleX = currentY - y;
                break;
            case FRONT:
                angleY = currentX - x;
                angleX = currentY - y;
                break;
            case SIDE:
                angleY = currentX - x;
                angleZ = currentY - y;
                break;
        }
        pro.changed();
        currentX = x;
        currentY = y;
    }

    public void mouseMoved(MouseEvent e) {
        currentX = e.getX();
        currentY = e.getY();
    }

    public void keyboard(char key, int x, int y) {
        switch (key) {
            case 't':
                glNewList (list, GL_COMPILE);
                    glColor3f (1.0f, 1.0f, 1.0f);
                    glutWireTeapot(0.8);
                glEndList ();
                pro.changed();
                break;
            case 'c':
                glNewList (list, GL_COMPILE);
                    glColor3f (1.0f, 1.0f, 1.0f);
                    glutWireCone(0.8, 1.5, 20, 20);
                glEndList ();
                pro.changed();
                break;
            case 'o':
                glNewList (list, GL_COMPILE);
                    glColor3f (1.0f, 1.0f, 1.0f);
                    glutWireTorus(0.3, 0.8, 20, 20);
                glEndList ();
                pro.changed();
                break;
            case 27:
                System.exit(0);
                break;
        }
    }
    
    public void main(View sharedView) {
        jsInitDisplayMode (GLUT_SINGLE | GLUT_RGB | GLUT_DOUBLE);
        glutInitWindowSize (200, 200); 
        if (sharedView == null) {
            createList = true;
            context = jsCreateContextAuto();
        } else {
            context = jsCreateContextAuto(sharedView.context);
        }
        jsInitFunc("init", this, context);
        jsDisplayFunc("display", this, context); 
        jsReshapeFunc("reshape", this, context);
        jsKeyboardFunc("keyboard", this, context);
    }
}
