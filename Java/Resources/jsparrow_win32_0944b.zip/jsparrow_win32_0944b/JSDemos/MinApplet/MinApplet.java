/*
 * MinApplet.java
 *     PFU Limited.  1999
 */
import java.applet.Applet;
import java.awt.*;
import jsparrow.gl.*;

public class MinApplet extends Applet {
    public void paint(Graphics g) {
        OGL o = new OGL();
        o.jsInitDisplayMode(o.GLUT_SINGLE);
        o.jsCreateContext(this);
        o.glMatrixMode(o.GL_PROJECTION);
        o.glOrtho(-5.0f, 5.0f, -5.0f, 5.0f, -5.0f, 5.0f);
        o.glMatrixMode(o.GL_MODELVIEW);
        o.glClear(o.GL_COLOR_BUFFER_BIT);
        o.glutWireTeapot(3.0);
        o.glFlush();
    }
}
