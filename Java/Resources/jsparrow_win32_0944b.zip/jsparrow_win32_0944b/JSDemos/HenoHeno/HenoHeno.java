/*
 * HenoHeno.java
 *     PFU Limited.  2000
 *
 *      Author  Keiko Nakayama
 *              Naruki Aruga
 */
import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import jsparrow.gl.*;
import java.awt.image.*;

public class HenoHeno extends Applet implements Runnable, ActionListener, ItemListener, WindowListener {
    TextureMapedCubeCanvas canvas;
    DrawingCanvas dCanvas;
    Choice colorChoice;
    
    Thread thread = null;
    
    static final Object colors[][] = {{"black", Color.black}, {"white", Color.white},
                                      {"red", Color.red}, {"blue", Color.blue},
                                      {"yellow", Color.yellow}, {"green", Color.green}};

    public void init() {
        int w = 400, h = 400;
        
        dCanvas = new DrawingCanvas(128, 128);
        Button clearButton = new Button("Clear");
        clearButton.addActionListener(this);
        colorChoice = new Choice();
        for (int i = 0; i < colors.length; i++) {
            colorChoice.add((String) colors[i][0]);
        }
        colorChoice.addItemListener(this);
        Panel drawingPanel = new Panel();
        drawingPanel.add(dCanvas);
        drawingPanel.add(colorChoice);
        drawingPanel.add(clearButton);
        canvas = new TextureMapedCubeCanvas(w, h);

        setLayout(new BorderLayout());
        add("West", canvas);
        add("Center", drawingPanel);
    }

    public void run() {
        while (thread != null) {
            if (dCanvas.isChanged()) {
                canvas.resetTexture(dCanvas.getImage());
                dCanvas.clearChanged();
            }
            canvas.repaint();
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void start() {
        if (thread == null) {
            thread = new Thread(this);
            thread.start();
        }
    }

    public void stop() {
        if (thread != null) {
            thread.stop();
            thread = null;
        }
    }

    public void actionPerformed(ActionEvent e) {
        dCanvas.clear();
    }

    public void itemStateChanged(ItemEvent e) {
        dCanvas.setColor((Color) colors[colorChoice.getSelectedIndex()][1]);
    }
    
    public void windowClosing(WindowEvent e) {
        System.exit(0);
    }
    public void windowActivated(WindowEvent e) {}
    public void windowClosed(WindowEvent e) {}
    public void windowDeactivated(WindowEvent e) {}
    public void windowDeiconified(WindowEvent e) {}
    public void windowIconified(WindowEvent e) {}
    public void windowOpened(WindowEvent e) {}
    
    /* for application */
    public static void main (String argv[]) {
        Frame frame = new Frame("HenoHeno");
        HenoHeno heno = new HenoHeno();
        heno.init();
        frame.add(heno);
        frame.setSize(550, 400);
        frame.show();
        heno.start();

        frame.addWindowListener(heno);
    }
}

class TextureMapedCubeCanvas extends OGLCanvas implements MouseMotionListener {
    /* light */
    double eyePosX = 0.0, eyePosY = 0.0, eyePosZ = 10.0;
    float light_diffuse[] = {1.0f, 1.0f, 1.0f, 1.0f};
    float light_ambient[] = {1.0f, 1.0f, 1.0f, 1.0f};
    float light_specular[] = {1.0f, 1.0f, 1.0f, 1.0f};
    float light_position[] = {1.0f, 1.0f, 2.0f, 0.0f};
    float clearR = 0.3f, clearG = 0.6f, clearB = 0.5f, clearA = 1.0f;

    /* shape */
    float normals[][] = {{0, 0, 1},{1, 0, 0},{0, 0, -1},{-1, 0, 0},{0, 1, 0},{0, -1, 0}};
    int faces[][] = {{0, 1, 2, 3},{1, 7, 6, 2},{4, 5, 6, 7},{0, 3, 5, 4},{2, 6, 5, 3},{0, 4, 7, 1}};
    float vertices[][] = {{-0.5f, -0.5f, 0.5f},{0.5f, -0.5f, 0.5f},{0.5f, 0.5f, 0.5f},{-0.5f, 0.5f, 0.5f},{-0.5f, -0.5f, -0.5f},{-0.5f, 0.5f, -0.5f},{0.5f, 0.5f, -0.5f},{0.5f, -0.5f, -0.5f}};

    /* color */
    float ambient[] = {0.3f, 0.3f, 0.3f, 1.0f};
    float diffuse[] = {0.8f, 0.8f, 0.8f, 1.0f};
    float specular[] = {0.0f, 0.0f, 0.0f, 1.0f};
    float emission[] = {0.0f, 0.0f, 0.0f, 1.0f};
    float shininess = 0.0f;
    
    /* transformation */
    float rotationX = 0.0f, rotationY = 0.0f;
    float translationX = 0.0f, translationY = 0.0f;
    float angleX = 0.0f, angleY = 0.0f;
    int mouseX = 0, mouseY = 0;
    int centerX, centerY;

    /* texture */
    byte texture[] = new byte[64 * 64 * 3];
    byte pixels[];

    /* other */
    int width, height;
    boolean reset = false;

    public TextureMapedCubeCanvas(int w, int h) {
        setSize(w, h);
        addMouseMotionListener(this);
        centerX = (int) (w * 0.5);
        centerY = (int) (h * 0.5);
        jsInitDisplayMode(GLUT_DOUBLE);
        OGLContext context = jsCreateContextAuto();
        jsInitFunc("init", this, context);
        jsDisplayFunc("display", this, context);
        jsReshapeFunc("reshape", this, context);
    }

    public void init() {
        glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
        glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
        glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
        glLightfv(GL_LIGHT0, GL_POSITION, light_position);
        glEnable(GL_LIGHT0);
        glEnable(GL_LIGHTING);
        glEnable(GL_NORMALIZE);
        glCullFace(GL_BACK);
        glEnable(GL_CULL_FACE);
        glShadeModel(GL_SMOOTH);
        glClearColor(clearR, clearG, clearB, clearA);
        glEnable(GL_DEPTH_TEST);
        glMaterialfv(GL_FRONT, GL_AMBIENT, ambient);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
        glMaterialf(GL_FRONT, GL_SHININESS, shininess);
        glMaterialfv(GL_FRONT, GL_EMISSION, emission);
    }

    public void display() {
        rotationX += angleX;
        rotationY += angleY;
        if (rotationX > 360.0f) {
            rotationX -= 360.0f;
        }
        if (rotationX < -360.0f) {
            rotationX += 360.0f;
        }
        if (rotationY > 360.0f) {
            rotationY -= 360.0f;
        }
        if (rotationY < -360.0f) {
            rotationY += 360.0f;
        }

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glPushMatrix();

        glTranslatef(translationX * -0.02f, translationY * 0.02f, 0.0f);
        glRotatef(rotationY, 0.0f, 1.0f, 0.0f);
        glRotatef(rotationX, 1.0f, 0.0f, 0.0f);
        glScalef(4.0f, 4.0f, 4.0f);

        if (reset) {
            setTexture();
            reset = false;
        }

        if (pixels == null) {
            for (int i = 0; i < faces.length; i ++) {
                glBegin(GL_POLYGON);
                glNormal3fv(normals[i]);
                glVertex3fv(vertices[faces[i][0]]);
                glVertex3fv(vertices[faces[i][1]]);
                glVertex3fv(vertices[faces[i][2]]);
                glVertex3fv(vertices[faces[i][3]]);
                glEnd();
            }
        } else {
            for (int i = 0; i < faces.length; i ++) {
                glBegin(GL_POLYGON);
                glNormal3fv(normals[i]);
                glTexCoord2f(0.0f, 1.0f);
                glVertex3fv(vertices[faces[i][0]]);
                glTexCoord2f(1.0f, 1.0f);
                glVertex3fv(vertices[faces[i][1]]);
                glTexCoord2f(1.0f, 0.0f);
                glVertex3fv(vertices[faces[i][2]]);
                glTexCoord2f(0.0f, 0.0f);
                glVertex3fv(vertices[faces[i][3]]);
                glEnd();
            }
        }
        glPopMatrix();
        swapBuffers();
    }

    void reshape(int w, int h) {
        centerX = (int) (w * 0.5);
        centerY = (int) (h * 0.5);
        glViewport(0, 0, w, h);
        centerX = w / 2;
        centerY = h / 2;
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(50.0, 1.0, 1.0, 100.0);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        gluLookAt(eyePosX, eyePosY, eyePosZ, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
    }
    
    void setTexture() {
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8/*3*/, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, pixels);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
        glEnable(GL_TEXTURE_2D);
    }

    void resetTexture(Image image) {
        createTexture(image);
        reset = true;
    }

    void createTexture(Image image) {
        PixelGrabber pg;
        int pixelsI[];
        
        width = image.getWidth(this);
        height = image.getHeight(this);
        pixelsI = new int[width * height];
        pixels = new byte[width * height * 3];
        pg = new PixelGrabber(image, 0, 0, width, height, pixelsI, 0, width);
        try {
            pg.grabPixels();
        } catch (InterruptedException e) {
        }
        
        for (int i = 0; i < (width * height); i++) {
            pixels[i * 3] = (byte) ((pixelsI[i] & 0x00FF0000) >> 16);
            pixels[i * 3 + 1] = (byte) ((pixelsI[i] & 0x0000FF00) >> 8);
            pixels[i * 3 + 2] = (byte) (pixelsI[i] & 0x000000FF);
        }
    }

    public void mouseDragged(MouseEvent e)  {
        translationX = mouseX - (e.getX() - centerX);
        translationY = mouseY - (e.getY() - centerY);
    }

    public void mouseMoved(MouseEvent e)  {
        mouseX = e.getX() - centerX;
        mouseY = e.getY() - centerY;
        angleY = (int) (((double) (mouseX + translationX) / (double) getSize().width) * 40);
        angleX = (int) (((double) (mouseY + translationY) / (double) getSize().height) * 40);
    }
}

class DrawingCanvas extends Canvas implements MouseMotionListener {
    int currentX, currentY;
    private Image image;
    private Graphics imageG;
    boolean changed = false;
    int width, height;

    boolean isChanged() {
        return changed;
    }

    void clearChanged() {
        changed = false;
    }

    DrawingCanvas(int w, int h) {
        super();
        addMouseMotionListener(this);
        setSize(w, h);
        width = w;
        height = h;
        setBackground(Color.white);
    }

    Graphics getImageGraphics() {
        if (imageG == null) {
            imageG = getImage().getGraphics();
        }
        return imageG;
    }

    Image getImage() {
        if (image == null) {
            image = createImage(128, 128);
        }
        return image;
    }

    public void clear() {
        getImageGraphics().fillRect(0, 0, 128, 128);
        changed = true;
        repaint();
    }

    public void setColor(Color c) {
        getImageGraphics().setColor(c);
    }

    public void update(Graphics g) {
        paint(g);
    }

    public void paint(Graphics g) {
        g.drawImage(getImage(), 0, 0, this);
        g.drawRect(0, 0, width - 1, height - 1);
    }

    public void mouseDragged(MouseEvent e)  {
        Graphics g = getImageGraphics();
        int x = e.getX();
        int y = e.getY();
        
        for (int i = 0; i < 3; i++) {
            g.drawLine(currentX + i, currentY + i, x, y + i);
        }
        currentX = x;
        currentY = y;
        
        repaint();
        changed = true;
    }

    public void mouseMoved(MouseEvent e)  {
        currentX = e.getX();
        currentY = e.getY();
    }
}
